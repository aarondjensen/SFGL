import { useState } from "react";
import { managerAuthApi } from "../api/supabase";

const styles = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  .sfgl-login-root {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Raleway', system-ui, sans-serif;
  }

  .sfgl-login-card {
    width: 100%;
    max-width: 420px;
    background: #0b1628;
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 2px;
    padding: 52px 48px 44px;
    box-shadow:
      0 0 0 1px rgba(180,160,100,0.12),
      0 40px 100px rgba(0,0,0,0.7),
      inset 0 1px 0 rgba(255,255,255,0.05);
    animation: sfglCardIn 0.55s cubic-bezier(0.22, 1, 0.36, 1) both;
  }

  @keyframes sfglCardIn {
    from { opacity: 0; transform: translateY(24px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  @keyframes sfglFadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  /* ── Header ── */
  .sfgl-login-header {
    text-align: center;
    margin-bottom: 36px;
    animation: sfglFadeUp 0.45s 0.1s cubic-bezier(0.22,1,0.36,1) both;
  }


  .sfgl-login-subtitle {
    font-family: 'Raleway', system-ui, sans-serif;
    font-size: 10px;
    font-weight: 500;
    color: rgba(255,255,255,0.3);
    letter-spacing: 3px;
    text-transform: uppercase;
  }

  /* ── Divider ── */
  .sfgl-divider {
    display: flex;
    align-items: center;
    gap: 14px;
    margin: 0 0 32px;
  }
  .sfgl-divider::before, .sfgl-divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(180,160,100,0.3), transparent);
  }
  .sfgl-divider-gem {
    color: rgba(180,160,100,0.45);
    font-size: 8px;
  }

  /* ── Fields ── */
  .sfgl-field {
    margin-bottom: 18px;
    animation: sfglFadeUp 0.4s cubic-bezier(0.22,1,0.36,1) both;
  }
  .sfgl-field:nth-of-type(1) { animation-delay: 0.15s; }
  .sfgl-field:nth-of-type(2) { animation-delay: 0.2s;  }

  .sfgl-label {
    display: block;
    font-size: 9.5px;
    font-weight: 600;
    color: rgba(255,255,255,0.35);
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 8px;
  }

  .sfgl-field-wrap { position: relative; }

  .sfgl-input {
    width: 100%;
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.1);
    border-bottom: 1px solid rgba(180,160,100,0.25);
    border-radius: 1px;
    padding: 12px 16px;
    font-family: 'Raleway', system-ui, sans-serif;
    font-size: 14px;
    font-weight: 400;
    color: #ffffff;
    outline: none;
    transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
    caret-color: rgba(180,160,100,0.8);
  }
  .sfgl-input::placeholder { color: rgba(255,255,255,0.15); }
  .sfgl-input:focus {
    border-color: rgba(180,160,100,0.5);
    background: rgba(255,255,255,0.06);
    box-shadow: 0 0 0 3px rgba(180,160,100,0.07), inset 0 -1px 0 rgba(180,160,100,0.4);
  }
  .sfgl-input.with-toggle { padding-right: 46px; }

  .sfgl-toggle {
    position: absolute; right: 13px; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer;
    color: rgba(255,255,255,0.2); padding: 4px;
    display: flex; align-items: center; transition: color 0.2s;
  }
  .sfgl-toggle:hover { color: rgba(255,255,255,0.5); }

  .sfgl-field-error {
    margin-top: 5px; font-size: 11px; color: #e07070;
    display: flex; align-items: center; gap: 4px;
  }
  .sfgl-hint {
    margin-top: 5px; font-size: 10.5px;
    color: rgba(255,255,255,0.2); font-style: italic;
  }

  /* ── Options ── */
  .sfgl-options {
    display: flex; align-items: center;
    margin-bottom: 26px;
    animation: sfglFadeUp 0.4s 0.25s cubic-bezier(0.22,1,0.36,1) both;
  }
  .sfgl-remember { display: flex; align-items: center; gap: 9px; cursor: pointer; user-select: none; }
  .sfgl-checkbox {
    width: 15px; height: 15px;
    appearance: none; -webkit-appearance: none;
    border: 1px solid rgba(255,255,255,0.2);
    border-radius: 1px;
    background: rgba(255,255,255,0.03);
    cursor: pointer; position: relative;
    transition: border-color 0.2s, background 0.2s; flex-shrink: 0;
  }
  .sfgl-checkbox:checked {
    background: #1c3a5e;
    border-color: rgba(180,160,100,0.6);
  }
  .sfgl-checkbox:checked::after {
    content: ''; position: absolute;
    left: 4px; top: 1px; width: 4px; height: 8px;
    border: 1.5px solid rgba(180,160,100,0.9);
    border-top: none; border-left: none;
    transform: rotate(45deg);
  }
  .sfgl-remember-text {
    font-size: 11px;
    color: rgba(255,255,255,0.3);
    letter-spacing: 0.5px;
  }

  /* ── Submit button ── */
  .sfgl-btn {
    width: 100%; padding: 14px;
    background: #1c3a5e;
    border: 1px solid rgba(180,160,100,0.25);
    border-radius: 1px;
    font-family: 'Raleway', system-ui, sans-serif;
    font-size: 11px; font-weight: 600;
    letter-spacing: 2.5px; text-transform: uppercase;
    color: rgba(255,255,255,0.9);
    cursor: pointer; transition: all 0.25s;
    position: relative; overflow: hidden;
    animation: sfglFadeUp 0.4s 0.3s cubic-bezier(0.22,1,0.36,1) both;
  }
  .sfgl-btn::before {
    content: ''; position: absolute; inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.06) 0%, transparent 60%);
    opacity: 0; transition: opacity 0.25s;
  }
  .sfgl-btn:hover::before { opacity: 1; }
  .sfgl-btn:hover {
    background: #1e3d7a;
    border-color: rgba(180,160,100,0.45);
    box-shadow: 0 4px 24px rgba(18,46,82,0.5), 0 0 0 1px rgba(180,160,100,0.2);
    transform: translateY(-1px);
  }
  .sfgl-btn:active { transform: translateY(0); }
  .sfgl-btn:disabled { opacity: 0.45; cursor: not-allowed; transform: none !important; }

  .sfgl-spinner {
    display: inline-block; width: 12px; height: 12px;
    border: 1.5px solid rgba(255,255,255,0.2);
    border-top-color: rgba(255,255,255,0.8);
    border-radius: 50%;
    animation: sfglSpin 0.65s linear infinite;
    vertical-align: middle; margin-right: 8px;
  }
  @keyframes sfglSpin { to { transform: rotate(360deg); } }

  .sfgl-server-error {
    background: rgba(180,60,60,0.1);
    border: 1px solid rgba(180,60,60,0.3);
    border-radius: 1px; padding: 11px 14px;
    font-size: 12px; color: #e07070;
    margin-bottom: 18px;
    animation: sfglFadeUp 0.25s ease both;
  }

  .sfgl-footer {
    margin-top: 28px; text-align: center;
    animation: sfglFadeUp 0.4s 0.35s cubic-bezier(0.22,1,0.36,1) both;
  }
  .sfgl-footer p {
    font-size: 10px;
    color: rgba(255,255,255,0.15);
    letter-spacing: 1px;
    text-transform: uppercase;
  }
`;

const EyeOpen = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
);
const EyeClosed = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
    <line x1="1" y1="1" x2="23" y2="23"/>
  </svg>
);

export default function LoginPage({ onLogin }) {
  const [name,        setName]        = useState('');
  const [password,    setPassword]    = useState('');
  const [showPw,      setShowPw]      = useState(false);
  const [remember,    setRemember]    = useState(true);
  const [loading,     setLoading]     = useState(false);
  const [serverError, setServerError] = useState('');
  const [errors,      setErrors]      = useState({});

  const validate = () => {
    const e = {};
    if (!name.trim())     e.name     = 'Please enter your name';
    if (!password.trim()) e.password = 'Please enter your password';
    return e;
  };

  const handleSubmit = async (evt) => {
    evt.preventDefault();
    setServerError('');
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    try {
      const result = await managerAuthApi.login(name.trim(), password.trim());
      if (onLogin) onLogin(result);
    } catch (err) {
      setServerError(err.message || 'Login failed — check your name and password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{styles}</style>
      <div className="sfgl-login-root">
        <div className="sfgl-login-card">

          <div className="sfgl-login-header">
            <div style={{
              fontFamily: "'Raleway', system-ui, sans-serif",
              fontSize: 32, fontWeight: 600, letterSpacing: 8,
              color: 'rgba(255,255,255,0.92)',
              textAlign: 'center', marginBottom: 16,
              userSelect: 'none',
            }}>SFGL</div>
            <p className="sfgl-login-subtitle">Manager Portal · 2026 Season</p>
          </div>

          <div className="sfgl-divider"><span className="sfgl-divider-gem">◆</span></div>

          <form onSubmit={handleSubmit} noValidate>
            {serverError && <div className="sfgl-server-error">⚠ {serverError}</div>}

            <div className="sfgl-field">
              <label htmlFor="sfgl-name" className="sfgl-label">Name</label>
              <div className="sfgl-field-wrap">
                <input id="sfgl-name" type="text" className="sfgl-input"
                  placeholder="Login name" value={name} autoFocus autoComplete="username"
                  onChange={e => { setName(e.target.value); setErrors(v => ({...v, name:''})); }}
                />
              </div>
              {errors.name
                ? <p className="sfgl-field-error">⚠ {errors.name}</p>
                : <p className="sfgl-hint">Crawforth · Fano · Hershey · Jensen · Lutz</p>
              }
            </div>

            <div className="sfgl-field">
              <label htmlFor="sfgl-password" className="sfgl-label">Password</label>
              <div className="sfgl-field-wrap">
                <input id="sfgl-password" type={showPw ? 'text' : 'password'}
                  className="sfgl-input with-toggle" placeholder="••••••••"
                  value={password} autoComplete="current-password"
                  onChange={e => { setPassword(e.target.value); setErrors(v => ({...v, password:''})); }}
                />
                <button type="button" className="sfgl-toggle"
                  onClick={() => setShowPw(v => !v)}
                  aria-label={showPw ? 'Hide password' : 'Show password'}>
                  {showPw ? <EyeClosed /> : <EyeOpen />}
                </button>
              </div>
              {errors.password
                ? <p className="sfgl-field-error">⚠ {errors.password}</p>
                : <p className="sfgl-hint">Enter the login name set by your commissioner</p>
              }
            </div>

            <div className="sfgl-options">
              <label className="sfgl-remember">
                <input type="checkbox" className="sfgl-checkbox" checked={remember}
                  onChange={e => setRemember(e.target.checked)} />
                <span className="sfgl-remember-text">Keep me logged in</span>
              </label>
            </div>

            <button type="submit" className="sfgl-btn" disabled={loading}>
              {loading && <span className="sfgl-spinner" />}
              {loading ? 'Signing In…' : 'Sign In'}
            </button>
          </form>

          <div className="sfgl-footer">
            <p>Sinclair Fantasy Golf League</p>
          </div>
        </div>
      </div>
    </>
  );
}
