import React, { useState } from 'react';
import { Settings } from 'lucide-react';
import { useDialog } from './DialogContext';
import { slashGolfFetch, getSegmentByDate } from '../utils';
import { storage } from '../api';
import { DraftModal } from './DraftModal';
import { managerAuthApi, tournamentResultsApi, sfglDataApi, playersApi } from '../api/supabase';
import { theme, colors, fonts } from '../theme.js';


// ── Tournament processing helpers ────────────────────────────────────────────
const BONUSES_REGULAR = { round1: 20000, round2: 40000, round3: 60000 };
const BONUSES_MAJOR   = { round1: 40000, round2: 80000, round3: 120000 };

const CHAR_MAP = {
  'ø':'o','ö':'o','ó':'o','ô':'o','õ':'o',
  'å':'a','ä':'a','á':'a','à':'a','â':'a','ã':'a',
  'ü':'u','ú':'u','ù':'u','û':'u',
  'é':'e','è':'e','ê':'e','ë':'e',
  'í':'i','ì':'i','î':'i','ï':'i',
  'ñ':'n','ç':'c','ß':'ss',
};

const normalizePlayerName = (name) => {
  if (!name) return '';
  let n = name.toLowerCase().trim();
  Object.keys(CHAR_MAP).forEach(ch => { n = n.replace(new RegExp(ch, 'g'), CHAR_MAP[ch]); });
  return n.replace(/[.-]/g, ' ').replace(/\s+/g, ' ').trim();
};

const matchPlayerName = (a, b) => {
  const na = normalizePlayerName(a);
  const nb = normalizePlayerName(b);
  if (na === nb) return true;
  const wa = na.split(' '); const wb = nb.split(' ');
  if (wa.length === wb.length) return wa.every(w => wb.includes(w));
  return false;
};

const getRosterForTournament = (team, tournamentIndex, allTransactions) => {
  let roster = [...team.roster];
  allTransactions
    .filter(tx => tx.team === team.name && tx.tournamentIndex !== undefined && tx.tournamentIndex <= tournamentIndex && tx.status !== 'pending')
    .sort((a, b) => a.tournamentIndex - b.tournamentIndex)
    .forEach(tx => {
      if (tx.droppedPlayer) roster = roster.filter(p => p.name !== tx.droppedPlayer);
      if (tx.player && !roster.some(p => p.name === tx.player)) roster.push({ name: tx.player });
    });
  return roster;
};

/**
 * Core tournament processing. Mirrors the original processTournamentResults logic.
 * Returns { newTeams, newStats, resultsData }.
 */
const processTournamentData = (tournament, tournamentData, teams, globalPlayerStats, _unusedNames, transactions = []) => {
  const bonuses = tournament.isMajor ? BONUSES_MAJOR : BONUSES_REGULAR;

  // Build earningsMap from the tournamentData
  const earningsMap = {};
  if (tournamentData.earningsMap instanceof Map) {
    tournamentData.earningsMap.forEach((earnings, name) => { earningsMap[name] = earnings; });
  } else if (tournamentData.earningsMap && typeof tournamentData.earningsMap === 'object') {
    Object.assign(earningsMap, tournamentData.earningsMap);
  } else if (Array.isArray(tournamentData.competitors)) {
    tournamentData.competitors.forEach(p => {
      const name = p.athlete?.displayName;
      const earn = p.earnings || 0;
      if (name && earn > 0) earningsMap[name] = earn;
    });
  }

  // Update global stats
  const newStats = { ...globalPlayerStats };
  Object.entries(earningsMap).forEach(([playerName, earnings]) => {
    if (!newStats[playerName]) newStats[playerName] = { eventsPlayed: 0, cutsMade: 0, pgaTourEarnings: 0 };
    newStats[playerName] = {
      ...newStats[playerName],
      eventsPlayed: newStats[playerName].eventsPlayed + 1,
      cutsMade:     newStats[playerName].cutsMade + (earnings > 0 ? 1 : 0),
      pgaTourEarnings: newStats[playerName].pgaTourEarnings + earnings,
    };
  });

  const tournamentIndex = -1; // used only for getRosterForTournament; -1 = ignore tx filtering
  const resultsData = { teams: {}, earningsMap: { ...earningsMap }, roundLeaders: tournamentData.roundLeaders || {}, fullLineups: {} };

  const newTeams = teams.map(team => {
    if (!team.lineup || team.lineup.length === 0) return team;

    resultsData.fullLineups[team.id] = [...team.lineup];

    const starterResults = team.lineup.map(playerName => {
      let earnings = earningsMap[playerName];
      if (earnings === undefined) {
        const mk = Object.keys(earningsMap).find(k => matchPlayerName(k, playerName));
        earnings = mk !== undefined ? earningsMap[mk] : 0;
      }
      return { playerName, earnings: earnings || 0 };
    });

    const topStarters = [...starterResults].sort((a, b) => b.earnings - a.earnings).slice(0, 5);
    let totalEarnings = topStarters.reduce((s, p) => s + p.earnings, 0);
    const bonusEarnings = { round1: 0, round2: 0, round3: 0 };
    const playersWithBonuses = {};

    if (tournamentData.roundLeaders) {
      ['round1', 'round2', 'round3'].forEach(round => {
        const leaders = Array.isArray(tournamentData.roundLeaders[round])
          ? tournamentData.roundLeaders[round]
          : (tournamentData.roundLeaders[round] ? [tournamentData.roundLeaders[round]] : []);
        leaders.forEach(leaderName => {
          if (!leaderName) return;
          const actual = team.lineup.find(pn => normalizePlayerName(pn) === normalizePlayerName(leaderName));
          if (actual) {
            bonusEarnings[round] = bonuses[round];
            totalEarnings += bonuses[round];
            if (!playersWithBonuses[actual]) playersWithBonuses[actual] = { total: 0, rounds: [] };
            playersWithBonuses[actual].total  += bonuses[round];
            playersWithBonuses[actual].rounds.push({ round: round.replace('round', ''), bonus: bonuses[round] });
          }
        });
      });
    }

    resultsData.teams[team.id] = {
      totalEarnings,
      bonuses: bonusEarnings,
      players: topStarters.map(s => ({
        name: s.playerName,
        earnings: s.earnings,
        limited: team.roster.find(p => p.name === s.playerName)?.limited || false,
        bonus: playersWithBonuses[s.playerName]?.total || 0,
        roundsLed: playersWithBonuses[s.playerName]?.rounds || [],
        wasRoundLeader: (playersWithBonuses[s.playerName]?.total || 0) > 0,
      })),
    };

    const updatedRoster = team.roster.map(player => {
      if (!team.lineup.includes(player.name)) return player;
      let pe = earningsMap[player.name];
      if (pe === undefined) { const mk = Object.keys(earningsMap).find(k => matchPlayerName(k, player.name)); if (mk) pe = earningsMap[mk]; }
      return { ...player, starts: (player.starts || 0) + 1, sfglEarnings: (player.sfglEarnings || 0) + (pe || 0) };
    });

    return {
      ...team,
      roster: updatedRoster,
      earnings: (team.earnings || 0) + totalEarnings,
      segmentEarnings: (team.segmentEarnings || 0) + totalEarnings,
      lineup: [],
    };
  });

  return { newTeams, newStats, resultsData };
};

export const AdminView = ({
  isCommissioner, setIsCommissioner, setActiveTab,
  settings, setSettings,
  teams, updateTeams,
  tournaments, setTournaments,
  transactions, setTransactions,
  allPlayers, globalPlayerStats, setGlobalPlayerStats,
  headshots, setHeadshots,
  updateRankings, rankingsLastUpdated,
  STORAGE_KEYS,
}) => {
  const [selectedTourney, setSelectedTourney] = useState('');
  const [manualEntry, setManualEntry] = useState({ round1Leaders: [''], round2Leaders: [''], round3Leaders: [''], playerEarnings: '', teamLineups: {} });
  const [rosterMgmtTeam, setRosterMgmtTeam] = useState('');
  const [playerSearch, setPlayerSearch] = useState('');
  const [mgCredTeam, setMgCredTeam] = useState('');
  const [hsSearch,   setHsSearch]   = useState('');
  const [hsSaving,   setHsSaving]   = useState({});
  const [mgCredName, setMgCredName] = useState('');
  const [mgCredPass, setMgCredPass] = useState('');
  const [mgCredSaving, setMgCredSaving] = useState(false);
  const [showDraftModal, setShowDraftModal] = useState(false);
  const [swingAwardSeg, setSwingAwardSeg]   = useState('');
  // Apply mulligan (live, inside Roster Management)
  const [mulliganMode, setMulliganMode]     = useState(false);
  const [mulliganOut,  setMulliganOut]      = useState('');
  const [mulliganIn,   setMulliganIn]       = useState('');
  const [mulliganRound, setMulliganRound]   = useState('2');
  // Retroactive lineup + mulligan + reprocess
  const [retMulTeam, setRetMulTeam] = useState('');
  const [retMulTourney, setRetMulTourney] = useState('');

  const [retLineupEdit, setRetLineupEdit] = useState([]);  // edited starting lineup
  const [mgrLoginOpen, setMgrLoginOpen]   = useState(false);
  const [inspectTeamId, setInspectTeamId] = useState('');
  const dialog = useDialog();

  React.useEffect(() => {
    const active = tournaments.find(t => t.playing);
    if (active && !selectedTourney) setSelectedTourney(active.name);
  }, [tournaments, selectedTourney]);

  const S = {
    section: { background: colors.cardBg, border: `1px solid ${colors.border}`, borderRadius: 4, padding: '16px 18px', marginBottom: 12 },
    title: { fontFamily: fonts.sans, fontSize: 11, fontWeight: 700, letterSpacing: '1.8px', textTransform: 'uppercase', color: colors.sectionHeaderBlue, marginBottom: 12 },
    btn: { ...theme.btnPrimary, width: '100%', padding: '10px 16px', textAlign: 'center', display: 'block', cursor: 'pointer' },
    btnSec: { ...theme.btnSecondary, width: '100%', padding: '10px 16px', textAlign: 'center', display: 'block', cursor: 'pointer' },
    btnDgr: { ...theme.btnDanger, width: '100%', padding: '10px 16px', textAlign: 'center', display: 'block', cursor: 'pointer' },
    input: { ...theme.input, marginBottom: 8 },
    select: { ...theme.select, marginBottom: 8, color: colors.textPrimary, backgroundColor: '#0d1b2e', appearance: 'none', WebkitAppearance: 'none' },
    lbl: { ...theme.label, display: 'block', marginBottom: 6 },
  };

  // ── Results: API fetch ───────────────────────────────────────────────────
  const handleFetchApiResults = async () => {
    if (!selectedTourney) { dialog.showToast('Select a tournament first', 'error'); return; }
    const ti = tournaments.findIndex(t => t.name === selectedTourney);
    const t = tournaments[ti];
    if (!t?.slashGolfId) { dialog.showToast('No API ID for this tournament', 'error'); return; }
    if (t.completed) {
      const ok = await dialog.showConfirm('Already Processed', 'Re-fetching will ADD earnings again (doubling them). Continue?', { type: 'danger', confirmText: 'Force Re-Fetch' });
      if (!ok) return;
    }
    try {
      dialog.showToast('Fetching ' + t.name + '...', 'info');
      let data = await slashGolfFetch('leaderboard', { tournId: t.slashGolfId, year: '2026' });
      let ap = data.leaderboardRows || data.leaderboard || data.results || [];
      if (!ap.length) { dialog.showToast('No results found in API yet.', 'error'); return; }
      try {
        const ed = await slashGolfFetch('earnings', { tournId: t.slashGolfId, year: '2026' });
        const ep = ed.leaderboard || ed.earnings || ed.results || [];
        if (ep.length) ap = ap.map(lp => ({ ...lp, earnings: ep.find(e => e.playerId === lp.playerId)?.earnings || 0 }));
      } catch (_) {}
      const names = teams.flatMap(t => t.roster.map(p => p.name));
      const { newTeams, newStats, resultsData } = processTournamentData(t, ap, teams, globalPlayerStats, names);
      const newT = tournaments.map((nt, i) => i === ti ? { ...nt, completed: true, playing: false, results: resultsData } : nt);
      const nx = newT.findIndex((nt, i) => i > ti && !nt.completed && !nt.isAlternate);
      if (nx !== -1) { newT.forEach(nt => { nt.playing = false; }); newT[nx].playing = true; }
      // Also apply sfglEarnings from resultsData.teams directly onto roster
      const teamsWithSfgl = newTeams.map(team => {
        const teamResult = resultsData?.teams?.[team.id];
        if (!teamResult?.players) return team;
        const earningsByName = {};
        teamResult.players.forEach(p => { earningsByName[p.name || p] = (p.earnings || 0); });
        return { ...team, roster: team.roster.map(p => earningsByName[p.name] !== undefined ? { ...p, sfglEarnings: (p.sfglEarnings || 0) + earningsByName[p.name] } : p) };
      });
      updateTeams(teamsWithSfgl); setGlobalPlayerStats(newStats); setTournaments(newT);
      await storage.set(STORAGE_KEYS.TEAMS, teamsWithSfgl);
      await storage.set(STORAGE_KEYS.TOURNAMENTS, newT);
      await storage.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats);
      sfglDataApi.set(STORAGE_KEYS.TEAMS, teamsWithSfgl).catch(() => {});
      sfglDataApi.set(STORAGE_KEYS.TOURNAMENTS, newT).catch(() => {});
      sfglDataApi.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats).catch(() => {});
      dialog.showToast('Results processed for ' + t.name + '!', 'success');
    } catch (err) { dialog.showToast('API Error: ' + err.message, 'error'); }
  };

  // ── Results: manual entry ────────────────────────────────────────────────
  const handleManualEntry = async () => {
    try {
      if (!selectedTourney) { dialog.showToast('Select a tournament first', 'error'); return; }
      const tournament = tournaments.find(t => t.name === selectedTourney);
      if (!tournament) { dialog.showToast('Tournament not found', 'error'); return; }
      if (tournament.completed) {
        const ok = await dialog.showConfirm('Already Processed', 'Re-entering will ADD earnings again (doubling them). Continue?', { type: 'danger', confirmText: 'Re-enter Results' });
        if (!ok) return;
      }
      // Parse earnings lines: "Player Name, 123456" or "Player Name, 1,234,567"
      const earningsMap = new Map();
      manualEntry.playerEarnings.split('\n').forEach(line => {
        const trimmed = line.trim();
        if (!trimmed) return;
        const m = trimmed.match(/^(.+?),\s*([\d,]+)$/);
        if (m) {
          const amt = parseInt(m[2].replace(/,/g, ''));
          if (!isNaN(amt) && amt >= 0) earningsMap.set(m[1].trim(), amt);
        }
      });
      if (!earningsMap.size) {
        dialog.showToast('No valid earnings lines found. Format: "Player Name, 123456"', 'error');
        return;
      }
      const ti = tournaments.findIndex(t => t.name === selectedTourney);
      const manualData = {
        name: selectedTourney, status: 'post', competitors: [],
        roundLeaders: {
          round1: manualEntry.round1Leaders.filter(l => l.trim()),
          round2: manualEntry.round2Leaders.filter(l => l.trim()),
          round3: manualEntry.round3Leaders.filter(l => l.trim()),
        },
        earningsMap, isManualEntry: true,
      };
      const names = teams.flatMap(t => t.roster.map(p => p.name));
      const { newTeams, newStats, resultsData } = processTournamentData(tournament, manualData, teams, globalPlayerStats, names, transactions);
      // Mark tournament completed, advance playing to next non-alternate
      const newT = tournaments.map((nt, i) => i === ti ? { ...nt, completed: true, playing: false, results: resultsData } : nt);
      const nx = newT.findIndex((nt, i) => i > ti && !nt.completed && !nt.isAlternate);
      if (nx !== -1) { newT.forEach(nt => { nt.playing = false; }); newT[nx].playing = true; }
      updateTeams(newTeams); setGlobalPlayerStats(newStats); setTournaments(newT);
      await storage.set(STORAGE_KEYS.TEAMS, newTeams);
      await storage.set(STORAGE_KEYS.TOURNAMENTS, newT);
      await storage.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats);
      await sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(e => console.error('sfgl teams sync:', e));
      await sfglDataApi.set(STORAGE_KEYS.TOURNAMENTS, newT).catch(e => console.error('sfgl tourney sync:', e));
      await sfglDataApi.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats).catch(e => console.error('sfgl stats sync:', e));
      dialog.showToast('Results processed! ' + earningsMap.size + ' players · ' + Object.keys(resultsData.teams).length + ' teams scored', 'success');
      setManualEntry({ round1Leaders: [''], round2Leaders: [''], round3Leaders: [''], playerEarnings: '', teamLineups: {} });
    } catch (err) {
      console.error('handleManualEntry error:', err);
      dialog.showToast('Error processing results: ' + err.message, 'error');
    }
  };

  // ── Results: reprocess completed tournament ─────────────────────────────
  const handleReprocess = async () => {
    if (!selectedTourney) { dialog.showToast('Select a tournament first', 'error'); return; }
    const tournament = tournaments.find(t => t.name === selectedTourney);
    if (!tournament?.completed) { dialog.showToast('Tournament is not yet completed', 'error'); return; }
    const ti = tournaments.findIndex(t => t.name === selectedTourney);

    const ok = await dialog.showConfirm(
      'Reprocess Tournament',
      'This will reverse the existing results for ' + selectedTourney + ' and apply the corrected earnings below. Team scores, player stats, and standings will all update.',
      { confirmText: 'Reprocess' }
    );
    if (!ok) return;

    try {
      // Parse corrected earnings
      const earningsMap = new Map();
      manualEntry.playerEarnings.split('\n').forEach(line => {
        const trimmed = line.trim();
        if (!trimmed) return;
        const m = trimmed.match(/^(.+?),\s*([\d,]+)$/);
        if (m) {
          const amt = parseInt(m[2].replace(/,/g, ''));
          if (!isNaN(amt) && amt >= 0) earningsMap.set(m[1].trim(), amt);
        }
      });
      if (!earningsMap.size) { dialog.showToast('No valid earnings lines found', 'error'); return; }

      // Step 1: Reverse old results from all teams
      const oldResults = tournament.results;
      let reversedTeams = teams.map(team => {
        const oldTeamResult = oldResults?.teams?.[team.id];
        if (!oldTeamResult) return team;
        // Reverse team earnings
        const earningsDelta = -(oldTeamResult.totalEarnings || 0);
        // Reverse per-player sfglEarnings and starts
        // Use fullLineups for start reversal (all starters), players list for earnings
        const oldLineup = new Set(oldResults.fullLineups?.[team.id] || (oldTeamResult.players || []).map(p => p.name || p));
        const oldEarningsByPlayer = {};
        (oldTeamResult.players || []).forEach(p => { oldEarningsByPlayer[p.name || p] = p.earnings || 0; });
        const newRoster = team.roster.map(p => {
          const wasInLineup = oldLineup.has(p.name);
          if (!wasInLineup) return p;
          return {
            ...p,
            sfglEarnings: Math.max(0, (p.sfglEarnings || 0) - (oldEarningsByPlayer[p.name] || 0)),
            starts: Math.max(0, (p.starts || 0) - 1),
          };
        });
        return {
          ...team,
          roster: newRoster,
          earnings: Math.max(0, (team.earnings || 0) + earningsDelta),
          segmentEarnings: Math.max(0, (team.segmentEarnings || 0) + earningsDelta),
          lineup: (manualEntry.teamLineups[team.id] || oldResults.fullLineups?.[team.id] || []),
        };
      });

      // Reverse global stats from old earningsMap
      const oldEarningsMap = oldResults?.earningsMap || {};
      const reversedStats = { ...globalPlayerStats };
      Object.entries(oldEarningsMap).forEach(([playerName, earnings]) => {
        if (!reversedStats[playerName]) return;
        reversedStats[playerName] = {
          ...reversedStats[playerName],
          eventsPlayed: Math.max(0, (reversedStats[playerName].eventsPlayed || 0) - 1),
          cutsMade: Math.max(0, (reversedStats[playerName].cutsMade || 0) - (earnings > 0 ? 1 : 0)),
          pgaTourEarnings: Math.max(0, (reversedStats[playerName].pgaTourEarnings || 0) - earnings),
        };
      });

      // Step 2: Apply corrected results
      const manualData = {
        name: selectedTourney, status: 'post', competitors: [],
        roundLeaders: {
          round1: manualEntry.round1Leaders.filter(l => l.trim()),
          round2: manualEntry.round2Leaders.filter(l => l.trim()),
          round3: manualEntry.round3Leaders.filter(l => l.trim()),
        },
        earningsMap, isManualEntry: true,
      };
      const names = teams.flatMap(t => t.roster.map(p => p.name));
      const { newTeams, newStats, resultsData } = processTournamentData(tournament, manualData, reversedTeams, reversedStats, names, transactions);

      // Mark tournament with new results (keep completed, don't change playing)
      const newT = tournaments.map((nt, i) => i === ti ? { ...nt, results: resultsData } : nt);

      updateTeams(newTeams); setGlobalPlayerStats(newStats); setTournaments(newT);
      await storage.set(STORAGE_KEYS.TEAMS, newTeams);
      await storage.set(STORAGE_KEYS.TOURNAMENTS, newT);
      await storage.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats);
      await sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
      await sfglDataApi.set(STORAGE_KEYS.TOURNAMENTS, newT).catch(() => {});
      await sfglDataApi.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats).catch(() => {});
      dialog.showToast('✓ Reprocessed ' + selectedTourney + ' with corrected earnings', 'success');
      setManualEntry({ round1Leaders: [''], round2Leaders: [''], round3Leaders: [''], playerEarnings: '', teamLineups: {} });
    } catch (err) {
      console.error('handleReprocess error:', err);
      dialog.showToast('Error reprocessing: ' + err.message, 'error');
    }
  };

    const RoundLeaderSelect = ({ label, leaders, onChange }) => {
    const players = teams.flatMap(team => (team.lineup || []).map(name => ({ name, team: team.name }))).sort((a, b) => a.name.localeCompare(b.name));
    return (
      <div style={{ flex: 1 }}>
        <div style={S.lbl}>{label}</div>
        {leaders.map((leader, idx) => (
          <div key={idx} style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
            <select value={leader} onChange={e => { const n = [...leaders]; n[idx] = e.target.value; onChange(n); }}
              style={{ ...theme.select, flex: 1, marginBottom: 0, fontSize: 12, padding: '7px 8px' }}>
              <option value="">(none)</option>
              {players.map(p => <option key={p.name + p.team} value={p.name}>{p.name} — {p.team}</option>)}
            </select>
            {idx > 0 && <button onClick={() => onChange(leaders.filter((_, i) => i !== idx))}
              style={{ background: 'none', border: `1px solid ${colors.dangerBorder}`, color: colors.danger, borderRadius: 2, padding: '4px 7px', cursor: 'pointer', fontSize: 11 }}>✕</button>}
          </div>
        ))}
        <button onClick={() => onChange([...leaders, ''])}
          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: colors.textGoldDim, padding: 0 }}>+ co-leader</button>
      </div>
    );
  };

  // ── Roster Management ────────────────────────────────────────────────────
  const handleAddPlayer = async (teamId, name) => {
    const newTeams = teams.map(t => t.id === teamId ? { ...t, roster: [...t.roster, { name, limited: false, unlimited: false, stars: 0, starts: 0, eventsPlayed: 0, cutsMade: 0, pgaTourEarnings: 0, sfglEarnings: 0, headshot: '' }] } : t);
    updateTeams(newTeams);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
    dialog.showToast('Added ' + name, 'success');
  };
  const handleDropPlayer = async (teamId, name, idx) => {
    const team = teams.find(t => t.id === teamId);
    const label = name || `roster entry #${idx + 1}`;
    if (!await dialog.showConfirm('Drop Player', 'Remove ' + label + ' from ' + team.name + '?', { type: 'danger', confirmText: 'Drop' })) return;
    // Drop by index if name is missing/ambiguous, otherwise by name
    const newRoster = idx !== undefined
      ? team.roster.filter((_, i) => i !== idx)
      : team.roster.filter(p => p.name !== name);
    const newTeams = teams.map(t => t.id === teamId ? { ...t, roster: newRoster } : t);
    updateTeams(newTeams);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
    dialog.showToast('Dropped ' + label, 'success');
  };
  const resetMulligan = (teamId, type) => {
    const team = teams.find(t => t.id === teamId);
    updateTeams(teams.map(t => t.id === teamId ? { ...t, mulligans: { ...t.mulligans, [type === 'sig' ? 'signatureMajor' : 'regular']: 1 } } : t));
    dialog.showToast('Reset ' + type + ' mulligan for ' + team.name, 'success');
  };

  // ── Waivers ──────────────────────────────────────────────────────────────
  const buildRoster = (team) => {
    let r = team.roster.map(p => p.name);
    transactions.filter(tx => tx.team === team.name && tx.status === 'processed' && tx.type !== 'mulligan').forEach(tx => {
      if (tx.droppedPlayer) r = r.filter(n => n !== tx.droppedPlayer);
      if (!r.includes(tx.player)) r.push(tx.player);
    });
    return new Set(r);
  };
  const applyWaiver = (t, w) => {
    if (t.name !== w.team) return t;
    let r = [...t.roster];
    if (w.droppedPlayer) r = r.filter(p => p.name !== w.droppedPlayer);
    if (!r.some(p => p.name === w.player)) r.push({ name: w.player, limited: false, unlimited: false, stars: 0, starts: 0, eventsPlayed: 0, cutsMade: 0, pgaTourEarnings: 0, sfglEarnings: 0, headshot: '' });
    return { ...t, roster: r };
  };
  const handleProcessSingle = async (w) => {
    const allRostered = new Set(); teams.forEach(t => t.roster.forEach(p => allRostered.add(p.name)));
    if (allRostered.has(w.player)) {
      const tx2 = transactions.map((tx, i) => i === w._idx ? { ...tx, status: 'failed', failReason: 'Player already rostered', processedDate: new Date().toLocaleDateString() } : tx);
      setTransactions(tx2); await storage.set(STORAGE_KEYS.TRANSACTIONS, tx2); sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, tx2).catch(() => {});
      dialog.showToast(w.player + ' already rostered', 'error'); return;
    }
    if (w.droppedPlayer && !teams.find(t => t.name === w.team)?.roster.some(p => p.name === w.droppedPlayer)) {
      const tx2 = transactions.map((tx, i) => i === w._idx ? { ...tx, status: 'failed', failReason: w.droppedPlayer + ' already dropped', processedDate: new Date().toLocaleDateString() } : tx);
      setTransactions(tx2); await storage.set(STORAGE_KEYS.TRANSACTIONS, tx2); sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, tx2).catch(() => {});
      dialog.showToast(w.droppedPlayer + ' already dropped', 'error'); return;
    }

    // Check for competing pending claims from other teams on the same player
    const competing = transactions
      .map((tx, i) => ({ ...tx, _idx: i }))
      .filter(tx => tx.status === 'pending' && tx.type === 'waiver' && tx.player === w.player && tx.team !== w.team);

    // Determine tiebreaker: lowest earnings wins
    const earningsMap = {}; teams.forEach(t => { earningsMap[t.name] = t.earnings || 0; });
    const allClaims = [w, ...competing].sort((a, b) => (earningsMap[a.team] || 0) - (earningsMap[b.team] || 0));
    const winner = allClaims[0];
    const losers = allClaims.slice(1);

    let tx2 = [...transactions];
    // Mark winner as processed
    tx2[winner._idx] = { ...tx2[winner._idx], status: 'processed', processedDate: new Date().toLocaleDateString() };
    // Mark losers as blocked
    losers.forEach(l => {
      tx2[l._idx] = { ...tx2[l._idx], status: 'failed', failReason: 'Waiver blocked — lost tiebreaker to ' + winner.team, processedDate: new Date().toLocaleDateString() };
    });

    // Only apply the winner's roster change
    const t2 = teams.map(t => applyWaiver(t, winner));
    setTransactions(tx2); updateTeams(t2);
    await storage.set(STORAGE_KEYS.TRANSACTIONS, tx2); await storage.set(STORAGE_KEYS.TEAMS, t2);
    sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, tx2).catch(() => {}); sfglDataApi.set(STORAGE_KEYS.TEAMS, t2).catch(() => {});
    if (losers.length) {
      dialog.showToast(winner.team + ' wins claim · ' + losers.map(l => l.team).join(', ') + ' blocked', 'success');
    } else {
      dialog.showToast(winner.team + ' adds ' + winner.player + (winner.droppedPlayer ? ' / drops ' + winner.droppedPlayer : ''), 'success');
    }
  };
  const handleProcessAll = async (pending) => {
    if (!pending.length) return;
    if (!await dialog.showConfirm('Process All Waivers', 'Process ' + pending.length + ' pending claim' + (pending.length !== 1 ? 's' : '') + '?\n\nTie-breaker: reverse standings (lowest earnings = highest priority).', { confirmText: 'Process All' })) return;
    const pm = {}; [...teams].sort((a, b) => (a.earnings || 0) - (b.earnings || 0)).forEach((t, i) => { pm[t.name] = i; });
    const byTeam = {}; pending.forEach(w => { if (!byTeam[w.team]) byTeam[w.team] = []; byTeam[w.team].push(w); });
    Object.values(byTeam).forEach(c => c.sort((a, b) => (a.priority || 999) - (b.priority || 999)));
    const allR = new Set(); teams.forEach(t => buildRoster(t).forEach(n => allR.add(n)));
    const dropped = new Set(), done = new Set(), failed = new Set(), applied = [];
    const tx2 = [...transactions]; let p = 0, f = 0, more = true;
    while (more) {
      more = false;
      const round = []; Object.entries(byTeam).forEach(([tn, claims]) => { const top = claims.find(c => !done.has(c._idx) && !failed.has(c._idx)); if (top) round.push({ tn, claim: top, o: pm[tn] ?? 999 }); });
      if (!round.length) break;
      const byP = {}; round.forEach(rc => { if (!byP[rc.claim.player]) byP[rc.claim.player] = []; byP[rc.claim.player].push(rc); });
      Object.entries(byP).forEach(([player, cs]) => {
        cs.sort((a, b) => a.o - b.o); const w = cs[0];
        if (allR.has(player)) { cs.forEach(c => { failed.add(c.claim._idx); tx2[c.claim._idx] = { ...tx2[c.claim._idx], status: 'failed', failReason: 'Player already rostered', processedDate: new Date().toLocaleDateString() }; f++; }); more = true; return; }
        if (w.claim.droppedPlayer && (dropped.has(w.claim.droppedPlayer) || !allR.has(w.claim.droppedPlayer))) { failed.add(w.claim._idx); tx2[w.claim._idx] = { ...tx2[w.claim._idx], status: 'failed', failReason: w.claim.droppedPlayer + ' already dropped', processedDate: new Date().toLocaleDateString() }; f++; more = true; return; }
        if (w.claim.droppedPlayer) { allR.delete(w.claim.droppedPlayer); dropped.add(w.claim.droppedPlayer); }
        allR.add(player); done.add(w.claim._idx); tx2[w.claim._idx] = { ...tx2[w.claim._idx], status: 'processed', processedDate: new Date().toLocaleDateString() }; applied.push(w.claim); p++;
        cs.slice(1).forEach(l => { failed.add(l.claim._idx); tx2[l.claim._idx] = { ...tx2[l.claim._idx], status: 'failed', failReason: 'Waiver blocked — lost tiebreaker to ' + w.tn, processedDate: new Date().toLocaleDateString() }; f++; }); more = true;
      });
    }
    let t2 = [...teams]; applied.forEach(w => { t2 = t2.map(t => applyWaiver(t, w)); });
    setTransactions(tx2); updateTeams(t2);
    await storage.set(STORAGE_KEYS.TRANSACTIONS, tx2); await storage.set(STORAGE_KEYS.TEAMS, t2);
    sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, tx2).catch(() => {}); sfglDataApi.set(STORAGE_KEYS.TEAMS, t2).catch(() => {});
    dialog.showToast('Processed ' + p + (f ? ' · ' + f + ' failed' : ''), p > 0 ? 'success' : 'error');
  };

  // ── Manager Login ────────────────────────────────────────────────────────
  const handleSetLogin = async () => {
    if (!mgCredTeam || !mgCredName || !mgCredPass) return;
    setMgCredSaving(true);
    try { await managerAuthApi.setCredentials(mgCredTeam, mgCredName, mgCredPass); dialog.showToast('Login set for ' + mgCredName, 'success'); setMgCredTeam(''); setMgCredName(''); setMgCredPass(''); }
    catch (e) { dialog.showToast('Failed: ' + e.message, 'error'); }
    setMgCredSaving(false);
  };

  // ── Push to Supabase ─────────────────────────────────────────────────────
  const handlePush = async () => {
    if (!await dialog.showConfirm('Push to Supabase', 'Overwrite the shared database with data from this device. All other devices update on next refresh.', { confirmText: 'Push' })) return;
    dialog.showToast('Pushing...', 'info');
    try {
      await Promise.all([sfglDataApi.set(STORAGE_KEYS.TEAMS, teams), sfglDataApi.set(STORAGE_KEYS.TOURNAMENTS, tournaments), sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, transactions), sfglDataApi.set(STORAGE_KEYS.SETTINGS, settings), sfglDataApi.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, globalPlayerStats)]);
      await Promise.all(tournaments.filter(t => t.completed && t.results).map(t => tournamentResultsApi.save({ tournamentName: t.name, teamResults: t.results.teams || {}, earningsMap: t.results.earningsMap || {}, roundLeaders: t.results.roundLeaders || {}, fullLineups: t.results.fullLineups || {} }).catch(() => {})));
      dialog.showToast('Pushed! Refresh mobile to sync.', 'success');
    } catch (e) { dialog.showToast('Push failed: ' + e.message, 'error'); }
  };

  // ── Recalculate Earnings ─────────────────────────────────────────────────
  const handleRecalc = async () => {
    const done = tournaments.filter(t => t.completed && t.results?.teams);
    if (!done.length) { dialog.showToast('No completed results found', 'error'); return; }
    if (!await dialog.showConfirm('Recalculate Earnings', 'Recompute all team earnings from completed results and fix the current tournament indicator.', { confirmText: 'Recalculate' })) return;
    const byTeam = {}; done.forEach(t => Object.entries(t.results.teams).forEach(([id, tr]) => { byTeam[id] = (byTeam[id] || 0) + (tr.totalEarnings || 0); }));
    const ut = teams.map(team => ({ ...team, earnings: byTeam[team.id] || 0, segmentEarnings: (() => { const sw = typeof getSegmentByDate === 'function' ? getSegmentByDate() : null; return done.filter(t => !sw || getTournamentSegment(t) === sw).reduce((s, t) => s + (t.results?.teams?.[team.id]?.totalEarnings || 0), 0); })() }));
    const li = [...tournaments].map((t, i) => ({ t, i })).filter(({ t }) => t.completed).pop()?.i ?? -1;
    const nx = tournaments.findIndex((t, i) => i > li && !t.completed && !t.isAlternate);
    const ft = tournaments.map((t, i) => ({ ...t, playing: i === nx }));
    updateTeams(ut); setTournaments(ft);
    await storage.set(STORAGE_KEYS.TEAMS, ut); await storage.set(STORAGE_KEYS.TOURNAMENTS, ft);
    dialog.showToast('Recalculated · next up: ' + (ft[nx]?.name || 'none'), 'success');
  };

  // ── Season Reset ─────────────────────────────────────────────────────────
  const handleReset = async () => {
    if (!await dialog.showConfirm('Reset Entire Season', 'DELETE all results, transactions, rosters, lineups, and stats. Cannot be undone.', { type: 'danger', confirmText: 'Continue' })) return;
    if (!await dialog.showConfirm('Final Warning', 'Are you absolutely sure? This wipes everything.', { type: 'danger', confirmText: 'Yes, Reset Everything' })) return;
    updateTeams(teams.map(t => ({ ...t, earnings: 0, segmentEarnings: 0, lineup: [], roster: [], mulligans: { signatureMajor: 1, regular: 1 } })));
    setTournaments(tournaments.map((t, i) => ({ ...t, completed: false, playing: i === 0, results: null })));
    setTransactions([]); setGlobalPlayerStats({});
    dialog.showToast('Season reset complete.', 'success');
  };

  // ── Apply Mulligan (live, from Roster Management) ───────────────────────
  const handleApplyMulligan = async (teamId) => {
    if (!mulliganOut || !mulliganIn) return;
    const team = teams.find(t => t.id === teamId);
    const activeTournament = tournaments.find(t => t.playing);
    if (!team || !activeTournament) { dialog.showToast('No active tournament', 'error'); return; }

    const isSignatureOrMajor = activeTournament.isSignature || activeTournament.isMajor;
    const mulliganKey = isSignatureOrMajor ? 'signatureMajor' : 'regular';
    const remaining = team.mulligans?.[mulliganKey] ?? 0;
    if (remaining < 1) { dialog.showToast('No ' + (isSignatureOrMajor ? 'signature/major' : 'regular') + ' mulligans remaining', 'error'); return; }

    const ok = await dialog.showConfirm('Apply Mulligan',
      team.name + ': swap ' + mulliganOut + ' OUT → ' + mulliganIn + ' IN (after Round ' + mulliganRound + ')?\n\nDeducts one ' + (isSignatureOrMajor ? 'signature/major' : 'regular') + ' mulligan.',
      { confirmText: 'Apply Mulligan' });
    if (!ok) return;

    // Update stored tournament results to swap mulliganed players so live starts count is correct
    const applyMulliganToResults = (tourns, teamId, outPlayer, inPlayer) =>
      tourns.map(t => {
        if (!t.playing || !t.results?.teams?.[teamId]) return t;
        const teamResult = t.results.teams[teamId];
        const updatedPlayers = (teamResult.players || []).map(p => {
          const name = p.name || p;
          if (name !== outPlayer) return p;
          // Replace out player with in player, preserve earnings structure
          return typeof p === 'string' ? inPlayer : { ...p, name: inPlayer, earnings: 0 };
        });
        return { ...t, results: { ...t.results, teams: { ...t.results.teams, [teamId]: { ...teamResult, players: updatedPlayers } } } };
      });

    const newLineup = team.lineup.map(p => p === mulliganOut ? mulliganIn : p);
    const updatedRoster = team.roster.map(p => {
      if (p.name === mulliganOut && p.limited) return { ...p, starts: Math.max(0, p.starts - 1) };
      if (p.name === mulliganIn  && p.limited) return { ...p, starts: p.starts + 1 };
      return p;
    });
    const newMulligans = { ...team.mulligans, [mulliganKey]: remaining - 1 };
    const tournamentIndex = tournaments.findIndex(t => t.playing);
    const newTx = {
      team: team.name, type: 'mulligan', player: mulliganIn, droppedPlayer: mulliganOut,
      fee: 0, segment: activeTournament.segment || '', date: new Date().toLocaleDateString(),
      timestamp: Date.now(),
      tournamentIndex, status: 'completed',
      mulliganType: isSignatureOrMajor ? 'signature/major' : 'regular',
      afterRound: parseInt(mulliganRound), tournament: activeTournament.name,
    };
    const newTeams = teams.map(t => t.id === teamId ? { ...t, lineup: newLineup, roster: updatedRoster, mulligans: newMulligans } : t);
    const newTournaments = applyMulliganToResults(tournaments, teamId, mulliganOut, mulliganIn);
    updateTeams(newTeams);
    setTournaments(newTournaments);
    setTransactions(prev => [...prev, newTx]);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    await storage.set(STORAGE_KEYS.TOURNAMENTS, newTournaments);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
    sfglDataApi.set(STORAGE_KEYS.TOURNAMENTS, newTournaments).catch(() => {});
    await storage.set(STORAGE_KEYS.TRANSACTIONS, [...transactions, newTx]);
    sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, [...transactions, newTx]).catch(() => {});

    dialog.showToast('Mulligan applied: ' + mulliganOut + ' → ' + mulliganIn, 'success');
    setMulliganMode(false); setMulliganOut(''); setMulliganIn(''); setMulliganRound('2');
  };

  // ── Retroactive Lineup Only (no mulligan) ─────────────────────────────
  const handleRetroLineupOnly = async () => {
    if (!retMulTeam || !retMulTourney) return;
    const team = teams.find(t => t.id === retMulTeam);
    const tournament = tournaments.find(t => t.name === retMulTourney);
    const tournamentIndex = tournaments.findIndex(t => t.name === retMulTourney);
    if (!team || !tournament || !tournament.results) return;

    const savedLineup = tournament.results.fullLineups?.[team.id] || [];
    const baseLineup = retLineupEdit.length > 0 ? retLineupEdit : savedLineup;
    if (baseLineup.length === 0) { dialog.showToast('No lineup to reprocess', 'error'); return; }

    const ok = await dialog.showConfirm(
      'Reprocess Lineup (No Mulligan)',
      'Reprocess ' + retMulTourney + ' for ' + team.name + ' with lineup: ' + baseLineup.join(', ') + '. No mulligan will be applied.',
      { confirmText: 'Reprocess' }
    );
    if (!ok) return;

    const teamsForReprocess = teams.map(t => t.id === team.id ? { ...t, lineup: baseLineup } : t);
    const earningsMap = tournament.results.earningsMap || {};
    const reprocessData = {
      name: retMulTourney, status: 'post', competitors: [],
      roundLeaders: tournament.results.roundLeaders || {},
      earningsMap: new Map(Object.entries(earningsMap)),
      isManualEntry: true,
    };
    const names = teams.flatMap(t => t.roster.map(p => p.name));
    const { newTeams: reprocessedTeams, newStats, resultsData } = processTournamentData(
      tournament, reprocessData, teamsForReprocess, globalPlayerStats, names
    );

    const oldTeamResult = tournament.results.teams?.[team.id];
    const newTeamResult = resultsData.teams?.[team.id];
    const oldSfglByPlayer = {};
    (oldTeamResult?.players || []).forEach(p => { oldSfglByPlayer[p.name || p] = p.earnings || 0; });
    const newSfglByPlayer = {};
    (newTeamResult?.players || []).forEach(p => { newSfglByPlayer[p.name || p] = p.earnings || 0; });

    const finalTeams = reprocessedTeams.map(t => {
      if (t.id !== team.id) return t;
      const newRoster = t.roster.map(p => {
        const delta = (newSfglByPlayer[p.name] || 0) - (oldSfglByPlayer[p.name] || 0);
        if (delta === 0) return p;
        return { ...p, sfglEarnings: Math.max(0, (p.sfglEarnings || 0) + delta) };
      });
      return { ...t, roster: newRoster };
    });

    const earningsDelta = (newTeamResult?.totalEarnings || 0) - (oldTeamResult?.totalEarnings || 0);
    const finalTeamsWithEarnings = finalTeams.map(t =>
      t.id === team.id
        ? { ...t, earnings: (t.earnings || 0) + earningsDelta, segmentEarnings: (t.segmentEarnings || 0) + earningsDelta }
        : t
    );

    const newTournamentResults = {
      ...tournament.results,
      teams: { ...tournament.results.teams, [team.id]: newTeamResult },
      fullLineups: { ...(tournament.results.fullLineups || {}), [team.id]: baseLineup },
    };
    const newTournaments = tournaments.map((t, i) =>
      i === tournamentIndex ? { ...t, results: newTournamentResults } : t
    );

    updateTeams(finalTeamsWithEarnings);
    setTournaments(newTournaments);
    setGlobalPlayerStats(newStats);
    await storage.set(STORAGE_KEYS.TEAMS, finalTeamsWithEarnings);
    await storage.set(STORAGE_KEYS.TOURNAMENTS, newTournaments);
    await storage.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newStats);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, finalTeamsWithEarnings).catch(() => {});

    dialog.showToast('Reprocessed ' + retMulTourney + ' for ' + team.name + (earningsDelta !== 0 ? ' · earnings delta $' + earningsDelta.toLocaleString() : ' · no earnings change'), 'success');
    setRetMulTeam(''); setRetMulTourney(''); setRetLineupEdit([]);
    setRetMulOut(''); setRetMulIn(''); setRetApplyMulligan(false);
  };


  // ── Award Swing Winner ──────────────────────────────────────────────────
  const SWINGS = ['West Coast Swing', 'Spring Swing', 'Summer Swing', 'Fall Finish'];

  // Get the swing a tournament belongs to, using t.segment if set,
  // otherwise infer from the tournament's own dates field (not today's date)
  const getTournamentSegment = (t) => {
    if (t.segment) return t.segment;
    // Parse month from dates: "Feb 9-15" → month=2
    if (t.dates) {
      const m = t.dates.match(/^([A-Za-z]+)/);
      if (m) {
        const months = {Jan:1,Feb:2,Mar:3,Apr:4,May:5,Jun:6,Jul:7,Aug:8,Sep:9,Oct:10,Nov:11,Dec:12};
        const mo = months[m[1]];
        if (mo) {
          if (mo >= 1 && mo <= 3) return 'West Coast Swing';
          if (mo >= 4 && mo <= 6) return 'Spring Swing';
          if (mo >= 7 && mo <= 9) return 'Summer Swing';
          return 'Fall Finish';
        }
      }
    }
    return null;
  };

  const handleSwingWinner = async () => {
    if (!swingAwardSeg) return;

    // Sum all transaction fees for this swing using tournamentIndex range,
    // matching the same logic as TransactionsView's fee counter.
    const swingTournaments = tournaments.filter(t => t.completed && getTournamentSegment(t) === swingAwardSeg && t.results?.teams);
    if (!swingTournaments.length) {
      dialog.showToast('No completed results found for ' + swingAwardSeg, 'error');
      return;
    }
    const swingIndexes = new Set(swingTournaments.map(t => tournaments.indexOf(t)));
    const pot = transactions
      .filter(tx => {
        if ((tx.fee || 0) <= 0) return false;
        if (tx.status === 'failed') return false;
        if (tx.type === 'swing_winner') return false;
        // Match by tournamentIndex if available, fall back to segment string
        return tx.tournamentIndex !== undefined
          ? swingIndexes.has(tx.tournamentIndex)
          : tx.segment === swingAwardSeg;
      })
      .reduce((sum, tx) => sum + tx.fee, 0);

    if (pot === 0) {
      dialog.showToast('No fees collected for ' + swingAwardSeg, 'error');
      return;
    }

    const byTeam = {};
    swingTournaments.forEach(t => {
      Object.entries(t.results.teams).forEach(([id, tr]) => {
        byTeam[id] = (byTeam[id] || 0) + (tr.totalEarnings || 0);
      });
    });

    // Debug: log what we found so issues are visible in console
    console.log('[SwingWinner] Swing:', swingAwardSeg);
    console.log('[SwingWinner] Tournaments found:', swingTournaments.map(t => t.name + ' (segment=' + t.segment + ', dates=' + t.dates + ')'));
    console.log('[SwingWinner] Earnings by team:', Object.entries(byTeam).map(([id, e]) => { const t = teams.find(x => x.id === id); return (t?.name || id) + ': $' + e.toLocaleString(); }));

    const winnerEntry = Object.entries(byTeam).sort((a, b) => b[1] - a[1])[0];
    if (!winnerEntry) { dialog.showToast('Could not determine winner', 'error'); return; }
    const [winnerId, winnerEarnings] = winnerEntry;
    const winnerTeam = teams.find(t => t.id === winnerId);
    if (!winnerTeam) { dialog.showToast('Winner team not found', 'error'); return; }

    const msg = swingAwardSeg + ' complete. Winner: ' + winnerTeam.name + ' (' + winnerTeam.owner + '). Swing: $' + winnerEarnings.toLocaleString() + '. Pot: $' + pot.toLocaleString() + '. Award pot?';
    const ok = await dialog.showConfirm('Award Swing Winner', msg, { confirmText: 'Award $' + pot.toLocaleString() });
    if (!ok) return;

    const lastSwingTournament = swingTournaments.reduce((last, t) => {
      const idx = tournaments.indexOf(t);
      return idx > (last?.idx ?? -1) ? { t, idx } : last;
    }, null);

    const newTx = {
      team: winnerTeam.name, type: 'swing_winner', player: winnerTeam.owner,
      fee: 0, amount: pot, segment: swingAwardSeg,
      date: new Date().toLocaleDateString(), status: 'completed',
      tournamentIndex: lastSwingTournament?.idx ?? undefined,
      note: swingAwardSeg + ' winner pot',
    };

    const newTeams = teams.map(t =>
      t.id === winnerId
        ? { ...t, earnings: (t.earnings || 0) + pot }
        : t
    );

    updateTeams(newTeams);
    setTransactions(prev => [...prev, newTx]);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    await storage.set(STORAGE_KEYS.TRANSACTIONS, [...transactions, newTx]);
    await sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(e => console.error('sfgl teams:', e));
    await sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, [...transactions, newTx]).catch(e => console.error('sfgl tx:', e));

    dialog.showToast('🏆 ' + winnerTeam.name + ' awarded $' + pot.toLocaleString() + ' for ' + swingAwardSeg, 'success');
    setSwingAwardSeg('');
  };

  // ── Recalculate Starts from History ────────────────────────────────────
  const handleRecalcStarts = async () => {
    const completed = tournaments.filter(t => t.completed && t.results?.teams);
    if (!completed.length) { dialog.showToast('No completed tournaments to calculate from', 'error'); return; }

    const ok = await dialog.showConfirm(
      'Recalculate Limited Player Starts',
      'Rebuild each limited player start count from completed tournament history. This is the source of truth and overrides any manual counts.',
      { confirmText: 'Recalculate' }
    );
    if (!ok) return;

    // Build starts map: teamId → playerName → count
    const startsMap = {};
    teams.forEach(t => { startsMap[t.id] = {}; });

    completed.forEach(tourney => {
      Object.entries(tourney.results.teams).forEach(([teamId, teamResult]) => {
        if (!startsMap[teamId]) return;
        // results.teams[id].players contains the players who contributed to the score
        const players = teamResult.players || [];
        players.forEach(p => {
          const name = p.name || p;
          if (!startsMap[teamId][name]) startsMap[teamId][name] = 0;
          startsMap[teamId][name] += 1;
        });
      });
    });

    // Apply mulligan corrections:
    // A mulligan-OUT means that player was replaced mid-tournament —
    // processTournamentData uses the post-mulligan lineup, so playerOut is NOT
    // in results.players and doesn't need a deduction.
    // A mulligan-IN means the replacement IS in results.players → already counted.
    // So the results.players list IS already the post-mulligan truth. No correction needed.

    const newTeams = teams.map(team => {
      const tMap = startsMap[team.id] || {};
      const newRoster = team.roster.map(p => {
        if (!p.limited) return p;
        const computedStarts = tMap[p.name] || 0;
        return { ...p, starts: computedStarts };
      });
      return { ...team, roster: newRoster };
    });

    updateTeams(newTeams);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});

    const totalFixed = teams.reduce((sum, team) => {
      return sum + team.roster.filter(p => p.limited).length;
    }, 0);
    dialog.showToast('Starts recalculated for ' + totalFixed + ' limited players across ' + completed.length + ' tournaments', 'success');
  };

  // ── Recalculate All Player Stats from History ──────────────────────────
  const handleRecalcAllStats = async () => {
    const completed = tournaments.filter(t => t.completed && t.results?.teams);
    if (!completed.length) { dialog.showToast('No completed tournaments found', 'error'); return; }

    const ok = await dialog.showConfirm(
      'Recalculate All Player Stats',
      'Rebuild Events, Cuts, Tour$, SFGL$, and Starts for every rostered player from completed tournament history.',
      { confirmText: 'Recalculate' }
    );
    if (!ok) return;

    // --- globalPlayerStats: {playerName: {eventsPlayed, cutsMade, pgaTourEarnings}}
    // sourced from results.earningsMap which has ALL players who made the cut
    const newGlobalStats = {};

    // --- per-roster sfglEarnings & starts: sourced from results.teams[id].players
    // {teamId: {playerName: {sfglEarnings, starts}}}
    const rosterStats = {};
    teams.forEach(t => { rosterStats[t.id] = {}; });

    completed.forEach(tourney => {
      const earningsMap = tourney.results.earningsMap || {};

      // PGA Tour stats from earningsMap (all players who earned money)
      Object.entries(earningsMap).forEach(([playerName, pgaEarnings]) => {
        if (!newGlobalStats[playerName]) {
          newGlobalStats[playerName] = { eventsPlayed: 0, cutsMade: 0, pgaTourEarnings: 0 };
        }
        newGlobalStats[playerName].eventsPlayed += 1;
        if (pgaEarnings > 0) newGlobalStats[playerName].cutsMade += 1;
        newGlobalStats[playerName].pgaTourEarnings += pgaEarnings;
      });

      // SFGL earnings & starts from each team result
      Object.entries(tourney.results.teams).forEach(([teamId, teamResult]) => {
        if (!rosterStats[teamId]) return;
        const players = teamResult.players || [];
        players.forEach(p => {
          const name = p.name || p;
          const sfgl = p.earnings || 0;
          if (!rosterStats[teamId][name]) rosterStats[teamId][name] = { sfglEarnings: 0, starts: 0 };
          rosterStats[teamId][name].sfglEarnings += sfgl;
          rosterStats[teamId][name].starts += 1;
        });
      });
    });

    // Apply to teams — update roster sfglEarnings and starts
    const newTeams = teams.map(team => {
      const tStats = rosterStats[team.id] || {};
      const newRoster = team.roster.map(p => {
        const ps = tStats[p.name] || { sfglEarnings: 0, starts: 0 };
        return {
          ...p,
          sfglEarnings: ps.sfglEarnings,
          starts: p.limited ? ps.starts : p.starts,
        };
      });
      return { ...team, roster: newRoster };
    });

    updateTeams(newTeams);
    setGlobalPlayerStats(newGlobalStats);
    await storage.set(STORAGE_KEYS.TEAMS, newTeams);
    await storage.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newGlobalStats);
    sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
    sfglDataApi.set(STORAGE_KEYS.GLOBAL_PLAYER_STATS, newGlobalStats).catch(() => {});

    const playerCount = Object.keys(newGlobalStats).length;
    dialog.showToast('Stats rebuilt from ' + completed.length + ' tournaments · ' + playerCount + ' players updated', 'success');
  };

  const pending = transactions.map((tx, idx) => ({ ...tx, _idx: idx })).filter(tx => tx.type === 'waiver' && tx.status === 'pending');
  const disabledBtn = (cond) => cond ? { opacity: 0.4, cursor: 'not-allowed' } : {};

  // ── OWGR CSV handler ──────────────────────────────────────────────────────
  const [owgrStatus, setOwgrStatus] = useState(null); // null | 'parsing' | 'done' | 'error'
  const [owgrSummary, setOwgrSummary] = useState('');

  const handleOwgrUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setOwgrStatus('parsing');
    setOwgrSummary('');
    e.target.value = ''; // reset input so same file can be re-uploaded

    try {
      const text = await file.text();
      const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length < 2) throw new Error('CSV appears empty');

      // Detect header row — find rank/name columns case-insensitively
      const header = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/['"]/g, ''));
      const rankCol = header.findIndex(h => h.includes('rank'));
      const nameCol = header.findIndex(h => h.includes('name') || h.includes('player'));
      if (nameCol === -1) throw new Error('Could not find a "name" or "player" column in CSV');

      const parsed = [];
      for (let i = 1; i < lines.length; i++) {
        // Handle quoted fields
        const cols = lines[i].match(/(".*?"|[^,]+)(?=,|$)/g)?.map(c => c.replace(/^"|"$/g, '').trim()) || lines[i].split(',').map(c => c.trim());
        const name = cols[nameCol];
        const rank = rankCol >= 0 ? parseInt(cols[rankCol], 10) : i;
        if (!name || name.toLowerCase() === 'name' || name.toLowerCase() === 'player') continue;
        parsed.push({ name, worldRank: isNaN(rank) ? i : rank });
      }

      if (parsed.length === 0) throw new Error('No players found in CSV');

      // Merge with existing allPlayers — update worldRank for matches, add new entries
      const updatedPlayers = [...allPlayers];
      let updated = 0, added = 0;

      parsed.forEach(({ name, worldRank }) => {
        const idx = updatedPlayers.findIndex(p => p.name.toLowerCase() === name.toLowerCase());
        if (idx >= 0) {
          updatedPlayers[idx] = { ...updatedPlayers[idx], worldRank };
          updated++;
        } else {
          updatedPlayers.push({ name, worldRank });
          added++;
        }
      });

      // Sort by rank
      updatedPlayers.sort((a, b) => (a.worldRank || 9999) - (b.worldRank || 9999));

      await updateRankings(updatedPlayers);
      setOwgrStatus('done');
      setOwgrSummary(`✓ ${parsed.length} players loaded · ${updated} updated · ${added} new`);
    } catch (err) {
      setOwgrStatus('error');
      setOwgrSummary(err.message || 'Failed to parse CSV');
    }
  };

  return (
    <div style={{ paddingBottom: 40 }}>

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 18px', background: colors.cardBg, border: `1px solid ${colors.border}`, borderRadius: 4, marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Settings size={14} style={{ color: colors.textGoldDim }} />
          <span style={{ fontFamily: fonts.sans, fontSize: 11, fontWeight: 700, letterSpacing: '2px', textTransform: 'uppercase', color: colors.textGold }}>Commissioner</span>
        </div>
        <button onClick={() => { setIsCommissioner(false); setActiveTab('standings'); }} style={{ ...theme.btnDanger, padding: '6px 14px', fontSize: 11 }}>Logout</button>
      </div>

      {/* ── Row 1: Tournament Results · Waivers · Swing Winner (side by side) ── */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>

        {/* Tournament Results */}
        <div style={{ ...S.section, flex: 2, minWidth: 0 }}>
          <div style={S.title}>🏆 Tournament Results</div>
          <label style={S.lbl}>Tournament</label>
          <select value={selectedTourney} onChange={e => {
            const name = e.target.value;
            setSelectedTourney(name);
            const t = tournaments.find(t => t.name === name);
            if (t?.completed && t.results?.earningsMap) {
              const lines = Object.entries(t.results.earningsMap)
                .sort((a, b) => b[1] - a[1])
                .map(([player, amt]) => player + ', ' + amt)
                .join('\n');
              const teamLineups = {};
              if (t.results.fullLineups) {
                Object.entries(t.results.fullLineups).forEach(([teamId, lineup]) => {
                  teamLineups[teamId] = [...lineup];
                });
              }
              setManualEntry(prev => ({ ...prev, playerEarnings: lines,
                round1Leaders: t.results.roundLeaders?.round1?.length ? t.results.roundLeaders.round1 : [''],
                round2Leaders: t.results.roundLeaders?.round2?.length ? t.results.roundLeaders.round2 : [''],
                round3Leaders: t.results.roundLeaders?.round3?.length ? t.results.roundLeaders.round3 : [''],
                teamLineups,
              }));
            } else {
              setManualEntry({ round1Leaders: [''], round2Leaders: [''], round3Leaders: [''], playerEarnings: '', teamLineups: {} });
            }
          }} style={S.select}>
            <option value="">Choose tournament...</option>
            {tournaments.map(t => <option key={t.name} value={t.name}>{t.completed ? '✓ ' : t.playing ? '▶ ' : ''}{t.name}</option>)}
          </select>
          <button onClick={handleFetchApiResults} style={{ ...S.btn, marginBottom: 10 }}>⚡ Fetch from API</button>

          <div style={{ borderTop: `1px solid ${colors.borderSubtle}`, paddingTop: 12 }}>
            <div style={{ ...S.lbl, color: colors.textMuted, textAlign: 'center', marginBottom: 10 }}>— or enter manually —</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
              <RoundLeaderSelect label="R1 Leader" leaders={manualEntry.round1Leaders} onChange={r => setManualEntry({ ...manualEntry, round1Leaders: r })} />
              <RoundLeaderSelect label="R2 Leader" leaders={manualEntry.round2Leaders} onChange={r => setManualEntry({ ...manualEntry, round2Leaders: r })} />
              <RoundLeaderSelect label="R3 Leader" leaders={manualEntry.round3Leaders} onChange={r => setManualEntry({ ...manualEntry, round3Leaders: r })} />
            </div>
            {/* ── Lineup overrides ── */}
            {tournaments.find(t => t.name === selectedTourney)?.completed && (
              <div style={{ marginBottom: 14 }}>
                <div style={{ ...S.lbl, marginBottom: 6 }}>
                  Starting Lineups
                  <span style={{ ...theme.smallText, textTransform: 'none', letterSpacing: 0, marginLeft: 6 }}>— correct if roster was edited</span>
                </div>
                {teams.map(team => {
                  const currentLineup = manualEntry.teamLineups[team.id] || [];
                  return (
                    <div key={team.id} style={{ marginBottom: 10, background: colors.inputBg, border: `1px solid ${colors.borderSubtle}`, borderRadius: 3, padding: '8px 12px' }}>
                      <div style={{ fontFamily: fonts.sans, fontSize: 11, fontWeight: 700, color: colors.textGold, marginBottom: 6, letterSpacing: '0.5px' }}>
                        {team.name}
                        <span style={{ color: colors.textMuted, fontWeight: 400, marginLeft: 8 }}>{currentLineup.length}/5 starters</span>
                      </div>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px 12px' }}>
                        {team.roster.map(p => {
                          const inLineup = currentLineup.includes(p.name);
                          return (
                            <label key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', userSelect: 'none' }}>
                              <input type="checkbox" checked={inLineup}
                                onChange={e => {
                                  const updated = e.target.checked ? [...currentLineup, p.name] : currentLineup.filter(n => n !== p.name);
                                  setManualEntry(prev => ({ ...prev, teamLineups: { ...prev.teamLineups, [team.id]: updated } }));
                                }}
                                style={{ accentColor: colors.textGold, width: 13, height: 13 }}
                              />
                              <span style={{ fontFamily: fonts.sans, fontSize: 11, color: inLineup ? colors.textPrimary : colors.textMuted }}>
                                {p.name}{p.limited && <span style={{ color: colors.textGoldDim, marginLeft: 3 }}>★</span>}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <label style={S.lbl}>Player Earnings <span style={{ ...theme.smallText, textTransform: 'none', letterSpacing: 0 }}>— one per line: Player Name, 123456</span></label>
            <textarea value={manualEntry.playerEarnings} onChange={e => setManualEntry({ ...manualEntry, playerEarnings: e.target.value })}
              placeholder={'Scottie Scheffler, 3600000\nRory McIlroy, 2160000'} rows={6}
              style={{ ...theme.input, fontFamily: fonts.mono, fontSize: 12, resize: 'vertical', marginBottom: 8 }} />
            <div style={{ display: 'flex', gap: 8 }}>
              {!tournaments.find(t => t.name === selectedTourney)?.completed && (
                <button onClick={handleManualEntry} disabled={!selectedTourney || !manualEntry.playerEarnings.trim()}
                  style={{ ...S.btn, flex: 1, ...disabledBtn(!selectedTourney || !manualEntry.playerEarnings.trim()) }}>
                  Process Manual Entry
                </button>
              )}
              {tournaments.find(t => t.name === selectedTourney)?.completed && (
                <button onClick={handleReprocess} disabled={!selectedTourney || !manualEntry.playerEarnings.trim()}
                  style={{ ...S.btn, flex: 1, background: 'rgba(220,150,50,0.12)', border: '1px solid rgba(220,150,50,0.4)', color: 'rgba(220,180,80,0.9)', ...disabledBtn(!selectedTourney || !manualEntry.playerEarnings.trim()) }}>
                  ✏️ Reprocess Tournament
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Waivers */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          {/* Reminder banner inside card */}
          {(() => {
            const now = new Date();
            const etOffset = -4;
            const etHour = (now.getUTCHours() + 24 + etOffset) % 24;
            const etDay  = new Date(now.getTime() + etOffset * 3600 * 1000).getUTCDay();
            const isReadyToProcess = etDay === 2 && etHour >= 20 && pending.length > 0;
            if (!isReadyToProcess) return null;
            return (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', marginBottom: 10, borderRadius: 3,
                background: 'rgba(220,170,60,0.1)', border: '1px solid rgba(220,170,60,0.45)',
              }}>
                <span style={{ fontSize: 14 }}>⏰</span>
                <div style={{ flex: 1, fontFamily: fonts.sans, fontSize: 11, color: 'rgba(220,190,80,0.9)', fontWeight: 600 }}>
                  Past 8pm ET Tuesday — process now!
                </div>
              </div>
            );
          })()}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={S.title}>⏰ Process Waivers</div>
            {pending.length > 0 && <span style={{ ...theme.badge, ...theme.badgeWarning }}>{pending.length} pending</span>}
          </div>
          {pending.length === 0 ? (
            <div style={{ ...theme.smallText, textAlign: 'center', padding: '8px 0', color: colors.success }}>✓ No pending waiver claims</div>
          ) : (
            <>
              <button onClick={() => handleProcessAll(pending)} style={{ ...S.btn, marginBottom: 8 }}>⚡ Process All ({pending.length})</button>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {pending.map(w => (
                  <div key={w._idx} style={{ display: 'flex', alignItems: 'center', gap: 10, background: colors.inputBg, border: `1px solid ${colors.borderSubtle}`, borderRadius: 3, padding: '8px 12px' }}>
                    <div style={{ width: 20, height: 20, borderRadius: '50%', background: 'rgba(220,170,60,0.1)', border: '1px solid rgba(220,170,60,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: colors.warning, flexShrink: 0 }}>{w.priority || '?'}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: fonts.sans, fontSize: 12, fontWeight: 600, color: colors.textPrimary }}>{w.team}</div>
                      <div style={{ fontSize: 11 }}>
                        <span style={{ color: colors.earningsGreen }}>+{w.player}</span>
                        {w.droppedPlayer && <span style={{ color: colors.danger }}> / -{w.droppedPlayer}</span>}
                      </div>
                    </div>
                    <button onClick={() => handleProcessSingle(w)} style={{ ...theme.btnSecondary, padding: '5px 10px', fontSize: 11, flexShrink: 0 }}>Process</button>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Swing Winner */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          <div style={S.title}>🏆 Award Swing Winner</div>
          <div style={{ ...theme.smallText, marginBottom: 10 }}>
            When a swing is complete, award the fee pot to the swing leader.
          </div>
          <label style={S.lbl}>Swing</label>
          <select value={swingAwardSeg} onChange={e => setSwingAwardSeg(e.target.value)} style={S.select}>
            <option value="">Select swing...</option>
            {SWINGS.map(s => {
              const pot = transactions.filter(tx => tx.segment === s && (tx.fee || 0) > 0).reduce((sum, tx) => sum + tx.fee, 0);
              const alreadyAwarded = transactions.some(tx => tx.type === 'swing_winner' && tx.segment === s);
              return (
                <option key={s} value={s} disabled={alreadyAwarded}>
                  {s}{pot > 0 ? ' · $' + pot.toLocaleString() + ' pot' : ''}{alreadyAwarded ? ' ✓ awarded' : ''}
                </option>
              );
            })}
          </select>
          {swingAwardSeg && (() => {
            const pot = transactions.filter(tx => tx.segment === swingAwardSeg && (tx.fee || 0) > 0).reduce((sum, tx) => sum + tx.fee, 0);
            const swingTourneys = tournaments.filter(t => t.completed && getTournamentSegment(t) === swingAwardSeg && t.results?.teams);
            const byTeam = {};
            swingTourneys.forEach(t => Object.entries(t.results.teams).forEach(([id, tr]) => { byTeam[id] = (byTeam[id] || 0) + (tr.totalEarnings || 0); }));
            const topEntry = Object.entries(byTeam).sort((a, b) => b[1] - a[1])[0];
            const leader = topEntry ? teams.find(t => t.id === topEntry[0]) : null;
            return (
              <div style={{ ...theme.smallText, marginBottom: 10, padding: '8px 10px', background: colors.inputBg, borderRadius: 3, border: `1px solid ${colors.borderSubtle}` }}>
                {leader
                  ? <span>🏆 Leader: <span style={{ color: colors.textGold, fontWeight: 600 }}>{leader.name}</span> · ${(topEntry[1] || 0).toLocaleString()} · <span style={{ color: colors.earningsGreen }}>Pot: ${pot.toLocaleString()}</span></span>
                  : <span style={{ color: colors.textMuted }}>No completed results for this swing yet</span>
                }
              </div>
            );
          })()}
          <button onClick={handleSwingWinner} disabled={!swingAwardSeg}
            style={{ ...S.btn, ...disabledBtn(!swingAwardSeg) }}>
            🏆 Award Swing Winner
          </button>
        </div>

      </div>{/* end Row 1 */}

      {/* ── Row 2: Roster Management · Fix Prior Lineup (side by side) ── */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>

        {/* Roster Management */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          <div style={S.title}>👥 Roster Management</div>
          <label style={S.lbl}>Team</label>
          <select value={rosterMgmtTeam} onChange={e => { setRosterMgmtTeam(e.target.value); setPlayerSearch(''); }} style={S.select}>
            <option value="">Choose team...</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          {rosterMgmtTeam && (() => {
            const team = teams.find(t => t.id === rosterMgmtTeam);

            // Compute effective roster the same way RostersView does —
            // start from team.roster and replay all processed transactions.
            // This is what the manager sees, and what we must edit.
            let effectiveRoster = [...team.roster];
            transactions
              .filter(tx => tx.team === team.name && tx.status === 'processed' && tx.type !== 'mulligan')
              .forEach(tx => {
                if (tx.droppedPlayer) effectiveRoster = effectiveRoster.filter(p => p.name !== tx.droppedPlayer);
                if (tx.player && !effectiveRoster.some(p => p.name === tx.player)) {
                  // Preserve full player object if already on roster, else create stub
                  const existing = team.roster.find(p => p.name === tx.player);
                  effectiveRoster.push(existing || { name: tx.player, limited: false, unlimited: false, stars: 0, starts: 0, eventsPlayed: 0, cutsMade: 0, pgaTourEarnings: 0, sfglEarnings: 0 });
                }
              });

            const effectiveNames = new Set(effectiveRoster.map(p => p.name));
            const results = playerSearch.trim() ? allPlayers.filter(p =>
              p.name && !/^\d+$/.test(p.name) &&
              p.name.toLowerCase().includes(playerSearch.toLowerCase()) &&
              !effectiveNames.has(p.name)
            ).slice(0, 15) : [];
            return (
              <div>
                <div style={{ background: colors.inputBg, border: `1px solid ${colors.borderSubtle}`, borderRadius: 3, padding: '10px 12px', marginBottom: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <span style={S.lbl}>Mulligans</span>
                    <span style={{ ...theme.smallText }}>Sig: {team.mulligans?.signatureMajor ?? 0} · Reg: {team.mulligans?.regular ?? 0}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                    <button onClick={() => resetMulligan(team.id, 'sig')} style={{ ...theme.btnSecondary, flex: 1, padding: '7px 10px', fontSize: 11 }}>Reset Sig</button>
                    <button onClick={() => resetMulligan(team.id, 'reg')} style={{ ...theme.btnSecondary, flex: 1, padding: '7px 10px', fontSize: 11 }}>Reset Reg</button>
                  </div>
                  {(() => {
                    const activeTournament = tournaments.find(t => t.playing);
                    if (!activeTournament) return (
                      <div style={{ ...theme.smallText, color: colors.textMuted, textAlign: 'center', paddingTop: 4 }}>No active tournament — can't apply mulligan</div>
                    );
                    const isSignatureOrMajor = activeTournament.isSignature || activeTournament.isMajor;
                    const mulliganKey = isSignatureOrMajor ? 'signatureMajor' : 'regular';
                    const remaining = team.mulligans?.[mulliganKey] ?? 0;
                    const lineupPlayers = team.lineup || [];
                    const benchPlayers = (team.roster || []).map(p => p.name).filter(n => !lineupPlayers.includes(n));
                    return (
                      <div>
                        <button
                          onClick={() => { setMulliganMode(!mulliganMode); setMulliganOut(''); setMulliganIn(''); setMulliganRound('2'); }}
                          style={{ ...theme.btnSecondary, width: '100%', padding: '7px 10px', fontSize: 11, marginBottom: mulliganMode ? 8 : 0,
                            borderColor: mulliganMode ? colors.border : colors.borderInput,
                            color: mulliganMode ? colors.textGold : colors.textSecondary }}>
                          🚨 {mulliganMode ? 'Cancel Mulligan' : 'Apply Mulligan'} ({remaining} {isSignatureOrMajor ? 'sig' : 'reg'} left)
                        </button>
                        {mulliganMode && (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                            <select value={mulliganOut} onChange={e => setMulliganOut(e.target.value)} style={{ ...S.select, marginBottom: 0 }}>
                              <option value="">Player OUT (from lineup)...</option>
                              {lineupPlayers.map(n => <option key={n} value={n}>{n}</option>)}
                            </select>
                            <select value={mulliganIn} onChange={e => setMulliganIn(e.target.value)} style={{ ...S.select, marginBottom: 0 }}>
                              <option value="">Player IN (from bench)...</option>
                              {benchPlayers.map(n => <option key={n} value={n}>{n}</option>)}
                            </select>
                            <div style={{ display: 'flex', gap: 4 }}>
                              {['1','2','3'].map(r => (
                                <button key={r} onClick={() => setMulliganRound(r)}
                                  style={{ flex: 1, padding: '6px 0', borderRadius: 2, fontSize: 11, fontFamily: fonts.sans, fontWeight: 600, cursor: 'pointer',
                                    background: mulliganRound === r ? colors.buttonNavy : 'transparent',
                                    border: `1px solid ${mulliganRound === r ? colors.border : colors.borderInput}`,
                                    color: mulliganRound === r ? colors.textGold : colors.textSecondary }}>
                                  R{r}
                                </button>
                              ))}
                            </div>
                            <button onClick={() => handleApplyMulligan(team.id)}
                              disabled={!mulliganOut || !mulliganIn || remaining < 1}
                              style={{ ...theme.btnPrimary, padding: '8px 10px', fontSize: 11,
                                opacity: (!mulliganOut || !mulliganIn || remaining < 1) ? 0.4 : 1,
                                cursor: (!mulliganOut || !mulliganIn || remaining < 1) ? 'not-allowed' : 'pointer' }}>
                              Confirm Mulligan
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
                <div style={{ border: `1px solid ${colors.borderSubtle}`, borderRadius: 3, marginBottom: 8 }}>
                  {!effectiveRoster.length
                    ? <div style={theme.emptyState}>No players on roster</div>
                    : effectiveRoster.map((p, idx) => (
                      <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderBottom: `1px solid ${colors.borderSubtle}` }}>
                        <span style={{ fontFamily: fonts.mono, fontSize: 10, color: colors.textMuted, flexShrink: 0, width: 18 }}>{idx + 1}</span>
                        <img src={'https://pga-tour-res.cloudflare.com/resources/photoplayer/' + (headshots[p.name] || 'default') + '.jpg'}
                          onError={e => { e.target.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(p.name || '?') + '&background=111d2e&color=9ca3af&size=28'; }}
                          alt="" style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover', border: `1px solid ${colors.borderSubtle}`, flexShrink: 0 }} />
                        <span style={{ fontFamily: fonts.sans, fontSize: 13, color: p.name ? colors.textPrimary : colors.danger, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {p.name || <em>unnamed entry</em>}
                        </span>
                        <button onClick={async () => {
                          const label = p.name || `entry #${idx + 1}`;
                          if (!await dialog.showConfirm('Drop Player', `Remove ${label} from ${team.name}?`, { type: 'danger', confirmText: 'Drop' })) return;
                          // Write the effective roster minus this player back to team.roster
                          const newRoster = effectiveRoster.filter((_, i) => i !== idx);
                          const newTeams = teams.map(t => t.id === team.id ? { ...t, roster: newRoster } : t);
                          updateTeams(newTeams);
                          await storage.set(STORAGE_KEYS.TEAMS, newTeams);
                          sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams).catch(() => {});
                          dialog.showToast('Dropped ' + label, 'success');
                        }} style={{ ...theme.btnDanger, padding: '4px 10px', fontSize: 11 }}>Drop</button>
                      </div>
                    ))
                  }
                </div>
                <input type="text" placeholder="Search to add player..." value={playerSearch} onChange={e => setPlayerSearch(e.target.value)} style={S.input} />
                {results.length > 0 && (
                  <div style={{ border: `1px solid ${colors.borderSubtle}`, borderRadius: 3, maxHeight: 160, overflowY: 'auto' }}>
                    {results.map(p => (
                      <button key={p.name} onClick={() => { handleAddPlayer(team.id, p.name); setPlayerSearch(''); }}
                        style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 12px', background: 'none', border: 'none', borderBottom: `1px solid ${colors.borderSubtle}`, cursor: 'pointer', textAlign: 'left' }}
                        onMouseEnter={e => e.currentTarget.style.background = colors.rowHover}
                        onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                        <span style={{ fontFamily: fonts.sans, fontSize: 13, color: colors.textPrimary }}>{p.name}</span>
                        <span style={{ fontSize: 11, color: colors.earningsGreen, fontWeight: 700 }}>Add</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}
        </div>

        {/* Fix Prior Lineup */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          <div style={S.title}>🚨 Fix Prior Lineup</div>
          <div style={{ ...theme.smallText, marginBottom: 12 }}>
            Correct a submitted lineup for a completed tournament and reprocess earnings.
          </div>
          <label style={S.lbl}>Team</label>
          <select value={retMulTeam} onChange={e => { setRetMulTeam(e.target.value); setRetLineupEdit([]); }} style={S.select}>
            <option value="">Select team...</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name} — {t.owner}</option>)}
          </select>
          <label style={S.lbl}>Tournament</label>
          <select value={retMulTourney} onChange={e => { setRetMulTourney(e.target.value); setRetLineupEdit([]); }} style={S.select}>
            <option value="">Select tournament...</option>
            {tournaments.filter(t => t.completed).map(t => (
              <option key={t.name} value={t.name}>✓ {t.name}</option>
            ))}
          </select>
          {retMulTeam && retMulTourney && (() => {
            const team = teams.find(t => t.id === retMulTeam);
            const tournament = tournaments.find(t => t.name === retMulTourney);
            const savedLineup = tournament?.results?.fullLineups?.[retMulTeam] || [];
            const baseLineup = retLineupEdit.length > 0 ? retLineupEdit : (savedLineup.length > 0 ? savedLineup : []);
            const rosterPlayers = team?.roster?.map(p => p.name) || [];
            return (
              <div>
                <label style={S.lbl}>
                  Lineup
                  <span style={{ ...theme.smallText, textTransform: 'none', letterSpacing: 0, marginLeft: 6 }}>
                    {savedLineup.length > 0 ? '(loaded from saved results)' : '(not saved — build manually)'}
                  </span>
                </label>
                <div style={{ marginBottom: 8, padding: '8px 10px', background: colors.inputBg, borderRadius: 3, border: '1px solid ' + colors.borderSubtle, fontSize: 11, fontFamily: fonts.sans }}>
                  {baseLineup.length > 0
                    ? baseLineup.map(name => (
                      <span key={name} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, marginRight: 8, marginBottom: 4 }}>
                        <span style={{ color: colors.textGold }}>{name}</span>
                        <button onClick={() => setRetLineupEdit(baseLineup.filter(n => n !== name))}
                          style={{ background: 'none', border: 'none', color: colors.danger, cursor: 'pointer', fontSize: 11, padding: '0 2px' }}>✕</button>
                      </span>
                    ))
                    : <span style={{ color: colors.textMuted }}>No lineup — add players below</span>
                  }
                </div>
                {baseLineup.length < 5 && (
                  <select onChange={e => { if (e.target.value) setRetLineupEdit([...baseLineup, e.target.value]); e.target.value = ''; }} style={{ ...S.select, marginBottom: 12 }}>
                    <option value="">+ Add player to lineup...</option>
                    {rosterPlayers.filter(n => !baseLineup.includes(n)).map(name => <option key={name} value={name}>{name}</option>)}
                  </select>
                )}
                <button onClick={handleRetroLineupOnly} disabled={baseLineup.length === 0}
                  style={{ ...S.btn, ...disabledBtn(baseLineup.length === 0) }}>
                  Reprocess Lineup
                </button>
              </div>
            );
          })()}
        </div>

      </div>{/* end Row 2 */}

      {/* ── Row 3: OWGR · Headshot Manager (side by side) ── */}
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>

        {/* OWGR Rankings */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          <div style={S.title}>🌍 Update OWGR Top 250</div>
          <div style={{ ...theme.smallText, marginBottom: 12 }}>
            Upload a CSV from owgr.com. Must include a <strong style={{ color: colors.textSecondary }}>name</strong> and <strong style={{ color: colors.textSecondary }}>rank</strong> column.
            {rankingsLastUpdated && (
              <span style={{ display: 'block', marginTop: 4, color: colors.textGoldDim }}>
                Last updated: {new Date(Number(rankingsLastUpdated)).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </span>
            )}
          </div>
          <label style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            ...S.btn,
            cursor: owgrStatus === 'parsing' ? 'wait' : 'pointer',
            opacity: owgrStatus === 'parsing' ? 0.6 : 1,
          }}>
            {owgrStatus === 'parsing' ? '⏳ Parsing…' : '📂 Choose CSV File'}
            <input type="file" accept=".csv,text/csv" onChange={handleOwgrUpload}
              style={{ display: 'none' }} disabled={owgrStatus === 'parsing'} />
          </label>
          {owgrSummary && (
            <div style={{
              marginTop: 10, padding: '8px 12px', borderRadius: 3, fontSize: 12, fontFamily: fonts.sans,
              background: owgrStatus === 'error' ? colors.dangerBg : 'rgba(80,160,100,0.1)',
              border: `1px solid ${owgrStatus === 'error' ? colors.dangerBorder : 'rgba(80,160,100,0.3)'}`,
              color: owgrStatus === 'error' ? colors.danger : colors.success,
            }}>
              {owgrSummary}
            </div>
          )}
        </div>

        {/* Headshot Manager */}
        <div style={{ ...S.section, flex: 1, minWidth: 0 }}>
          <div style={S.title}>🖼 Headshot Manager</div>
          <div style={{ ...theme.smallText, marginBottom: 10, color: colors.textSecondary }}>
            Map rostered players to their PGA Tour ID. Find the ID in the pgatour.com URL: /player/<strong style={{ color: colors.textPrimary }}>28237</strong>/rory-mcilroy
          </div>
          <input type="text" placeholder="Filter players…"
            value={hsSearch} onChange={e => setHsSearch(e.target.value)}
            style={{ ...theme.input, marginBottom: 10, fontSize: 12 }}
          />
          {(() => {
            // Build effective roster for all teams (same as useRoster) so
            // transaction-added players aren't missed.
            const rosteredNames = [...new Set(teams.flatMap(t => {
              const rosterSet = new Set(t.roster.map(p => p.name));
              transactions
                .filter(tx => tx.team === t.name && tx.type !== 'mulligan' && tx.status === 'processed')
                .forEach(tx => {
                  if (tx.droppedPlayer) rosterSet.delete(tx.droppedPlayer);
                  if (tx.player) rosterSet.add(tx.player);
                });
              return [...rosterSet];
            }))].filter(Boolean).sort();
            const missing = rosteredNames.filter(n => !headshots[n]);
            const filtered = hsSearch.trim()
              ? [...new Set([
                  // Rostered players matching search
                  ...rosteredNames.filter(n => n.toLowerCase().includes(hsSearch.toLowerCase())),
                  // All ranked players matching search (catches non-rostered players)
                  ...allPlayers
                    .filter(p => p.name && p.name.toLowerCase().includes(hsSearch.toLowerCase()))
                    .map(p => p.name),
                ])]
              : missing;
            const showingAll = hsSearch.trim().length > 0;
            return (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                <div style={{ ...theme.smallText, marginBottom: 6, color: colors.textMuted }}>
                  {showingAll
                    ? `Showing ${filtered.length} result${filtered.length !== 1 ? 's' : ''} (all ranked players)`
                    : missing.length === 0
                      ? <span style={{ color: colors.success }}>✓ All rostered players have headshot IDs</span>
                      : `${missing.length} player${missing.length !== 1 ? 's' : ''} missing IDs`
                  }
                </div>
                {filtered.map(name => {
                  const currentId = headshots[name] || '';
                  const hasSrc    = !!currentId;
                  const saving    = hsSaving[name];
                  return (
                    <div key={name} style={{
                      display: 'flex', alignItems: 'center', gap: 8,
                      background: colors.inputBg, border: `1px solid ${hasSrc ? colors.borderSubtle : 'rgba(220,100,80,0.25)'}`,
                      borderRadius: 3, padding: '6px 10px',
                    }}>
                      <img
                        src={hasSrc
                          ? (currentId.startsWith('http') ? currentId : `https://pga-tour-res.cloudinary.com/image/upload/c_thumb,g_face,z_0.7,q_auto,f_auto,dpr_2.0,w_96,h_96,b_rgb:F2F2F2,d_stub:default_avatar_light.webp/headshots_${currentId}`)
                          : `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1c3a5e&color=ffffff&size=96&bold=true&font-size=0.38`
                        }
                        onError={e => { e.target.onerror = null; e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=1c3a5e&color=ffffff&size=96&bold=true&font-size=0.38`; }}
                        alt="" style={{ width: 32, height: 32, borderRadius: '50%', objectFit: 'cover', border: `1px solid ${colors.borderSubtle}`, flexShrink: 0 }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontFamily: fonts.sans, fontSize: 12, color: colors.textPrimary, fontWeight: 500 }}>{name}</div>
                        {!hasSrc && <div style={{ fontFamily: fonts.sans, fontSize: 10, color: 'rgba(220,100,80,0.8)' }}>No ID set</div>}
                      </div>
                      <input
                        type="text" defaultValue={currentId} placeholder="PGA Tour ID"
                        onKeyDown={e => { if (e.key === 'Enter') e.target.blur(); }}
                        onBlur={async e => {
                          const val = e.target.value.trim();
                          if (val === currentId) return;
                          setHsSaving(prev => ({ ...prev, [name]: true }));
                          try {
                            await playersApi.update(name, { pgaTourId: val ? parseInt(val) || val : null });
                            setHeadshots({ ...headshots, [name]: val });
                            dialog.showToast('✓ Updated ' + name, 'success');
                          } catch(err) {
                            if (err.message?.includes('players_pga_tour_id_key')) {
                              const existing = Object.entries(headshots).find(([n, id]) => String(id) === String(val) && n !== name);
                              const who = existing ? ` — already assigned to "${existing[0]}"` : ' — already assigned to another player';
                              dialog.showToast(`ID ${val} is a duplicate${who}`, 'error');
                              e.target.value = currentId;
                            } else {
                              dialog.showToast('Error: ' + err.message, 'error');
                            }
                          } finally {
                            setHsSaving(prev => ({ ...prev, [name]: false }));
                          }
                        }}
                        style={{ ...theme.input, width: 100, fontSize: 12, padding: '5px 8px', marginBottom: 0,
                          textAlign: 'center', fontFamily: fonts.mono, opacity: saving ? 0.5 : 1 }}
                      />
                    </div>
                  );
                })}
                {filtered.length === 0 && (
                  <div style={{ ...theme.smallText, textAlign: 'center', padding: '12px 0' }}>No players found</div>
                )}
              </div>
            );
          })()}
        </div>

      </div>{/* end Row 3 */}

      {/* ── Data & Sync (with Manager Login as expandable subsection) ── */}
      <div style={S.section}>
        <div style={S.title}>☁️ Data & Sync</div>
        <button onClick={handlePush} style={{ ...S.btn, marginBottom: 8 }}>☁️ Push to Supabase (sync all devices)</button>
        <button onClick={async () => {
          dialog.showToast('Pulling from Supabase...', 'info');
          try {
            const rows = await sfglDataApi.getMany([STORAGE_KEYS.TEAMS, STORAGE_KEYS.TOURNAMENTS, STORAGE_KEYS.TRANSACTIONS]);
            if (rows[STORAGE_KEYS.TEAMS]?.length > 0) updateTeams(rows[STORAGE_KEYS.TEAMS]);
            if (rows[STORAGE_KEYS.TOURNAMENTS]?.length > 0) setTournaments(rows[STORAGE_KEYS.TOURNAMENTS]);
            if (rows[STORAGE_KEYS.TRANSACTIONS]?.length > 0) setTransactions(rows[STORAGE_KEYS.TRANSACTIONS]);
            dialog.showToast('✓ Pulled latest data from Supabase', 'success');
          } catch (e) { dialog.showToast('Pull failed: ' + e.message, 'error'); }
        }} style={{ ...S.btnSec, marginBottom: 8 }}>⬇️ Pull from Supabase (refresh this device)</button>
        <button onClick={handleRecalc} style={{ ...S.btnSec, marginBottom: 8 }}>📊 Recalculate Earnings from Results</button>
        <button onClick={handleRecalcAllStats} style={{ ...S.btnSec, marginBottom: 8 }}>📈 Recalculate All Player Stats (Events/Cuts/Tour$/SFGL$)</button>
        <button onClick={handleRecalcStarts} style={{ ...S.btnSec, marginBottom: 8 }}>⭐ Recalculate Limited Player Starts</button>
        <button onClick={async () => {
          // Read transactions from localStorage and merge any missing into current state
          try {
            const local = await storage.get(STORAGE_KEYS.TRANSACTIONS, []);
            if (!Array.isArray(local) || local.length === 0) {
              dialog.showToast('No transactions found in localStorage', 'error'); return;
            }
            const currentIds = new Set(transactions.map(tx => tx.timestamp || JSON.stringify(tx)));
            const missing = local.filter(tx => !currentIds.has(tx.timestamp || JSON.stringify(tx)));
            if (missing.length === 0) {
              dialog.showToast('No missing transactions found — localStorage matches Supabase', 'success'); return;
            }
            const ok = await dialog.showConfirm(
              'Recover Transactions',
              `Found ${missing.length} transaction(s) in localStorage not in Supabase:\n\n` +
              missing.slice(0, 5).map(tx => `• ${tx.team}: ${tx.type} ${tx.player || ''}`).join('\n') +
              (missing.length > 5 ? `\n...and ${missing.length - 5} more` : '') +
              '\n\nMerge these into transaction history?',
              { confirmText: `Recover ${missing.length}` }
            );
            if (!ok) return;
            const merged = [...missing, ...transactions];
            setTransactions(merged);
            await sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, merged);
            dialog.showToast(`✓ Recovered ${missing.length} transaction(s)`, 'success');
          } catch(e) { dialog.showToast('Recovery failed: ' + e.message, 'error'); }
        }} style={{ ...S.btnSec, marginBottom: 16 }}>🔄 Recover Transactions from localStorage</button>

        {/* ── Raw Roster Inspector / Direct Fix ── */}
        <div style={{ borderTop: `1px solid ${colors.borderSubtle}`, paddingTop: 12, marginBottom: 12 }}>
          <div style={{ fontFamily: fonts.sans, fontSize: 11, fontWeight: 700, color: colors.warning, letterSpacing: '0.5px', textTransform: 'uppercase', marginBottom: 8 }}>
            🔧 Raw Roster Inspector
          </div>
          <select value={inspectTeamId} onChange={e => setInspectTeamId(e.target.value)} style={{ ...S.select, marginBottom: 8 }}>
            <option value="">Select team to inspect...</option>
            {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
          {inspectTeamId && (() => {
            const team = teams.find(t => t.id === inspectTeamId);
            if (!team) return null;
            const teamTx = transactions.map((tx, i) => ({ ...tx, _i: i })).filter(tx => tx.team === team.name && (tx.type === 'waiver' || tx.type === 'free agent'));
            return (
              <div>
                <div style={{ fontFamily: fonts.sans, fontSize: 11, color: colors.textSecondary, marginBottom: 4 }}>
                  <strong>team.roster</strong> — {team.roster.length} players (what AdminView reads):
                </div>
                <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 3, padding: '8px 10px', marginBottom: 10, fontFamily: fonts.mono, fontSize: 11 }}>
                  {team.roster.length === 0
                    ? <span style={{ color: colors.textMuted }}>empty</span>
                    : team.roster.map((p, i) => (
                      <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '2px 0', borderBottom: `1px solid ${colors.borderSubtle}` }}>
                        <span style={{ color: colors.textPrimary }}>{i + 1}. {p.name || <em style={{ color: colors.danger }}>UNNAMED</em>}</span>
                        <button onClick={async () => {
                          if (!window.confirm(`Directly remove "${p.name || 'entry #' + (i+1)}" from team.roster? This bypasses all logic.`)) return;
                          const newRoster = team.roster.filter((_, ri) => ri !== i);
                          const newTeams = teams.map(t => t.id === team.id ? { ...t, roster: newRoster } : t);
                          updateTeams(newTeams);
                          await storage.set(STORAGE_KEYS.TEAMS, newTeams);
                          await sfglDataApi.set(STORAGE_KEYS.TEAMS, newTeams);
                          dialog.showToast('Removed from roster', 'success');
                        }} style={{ fontFamily: fonts.sans, fontSize: 10, padding: '1px 6px', background: 'rgba(180,60,60,0.2)', border: '1px solid rgba(180,60,60,0.4)', color: colors.danger, borderRadius: 2, cursor: 'pointer' }}>
                          ✕ Remove
                        </button>
                      </div>
                    ))
                  }
                </div>
                <div style={{ fontFamily: fonts.sans, fontSize: 11, color: colors.textSecondary, marginBottom: 4 }}>
                  <strong>Waiver/FA transactions</strong> — what useRoster replays:
                </div>
                <div style={{ background: 'rgba(0,0,0,0.3)', borderRadius: 3, padding: '8px 10px', fontFamily: fonts.mono, fontSize: 10, maxHeight: 200, overflowY: 'auto' }}>
                  {teamTx.length === 0
                    ? <span style={{ color: colors.textMuted }}>none</span>
                    : teamTx.map((tx, i) => (
                      <div key={i} style={{ padding: '3px 0', borderBottom: `1px solid ${colors.borderSubtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                        <span style={{ color: tx.status === 'processed' ? colors.success : tx.status === 'failed' ? colors.danger : colors.warning }}>
                          [{tx.status}] +{tx.player}{tx.droppedPlayer ? ' / -' + tx.droppedPlayer : ''}
                          {tx.failReason ? <span style={{ color: colors.textMuted }}> ({tx.failReason})</span> : null}
                        </span>
                        {tx.status === 'processed' && (
                          <button onClick={async () => {
                            if (!window.confirm(`Mark this transaction as FAILED to stop useRoster from replaying it?\n\n+${tx.player}${tx.droppedPlayer ? ' / -' + tx.droppedPlayer : ''}`)) return;
                            const newTx = transactions.map((t, i) => i === tx._i ? { ...t, status: 'failed', failReason: 'Manually voided by commissioner' } : t);
                            setTransactions(newTx);
                            await storage.set(STORAGE_KEYS.TRANSACTIONS, newTx);
                            await sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, newTx);
                            dialog.showToast('Transaction voided', 'success');
                          }} style={{ fontFamily: fonts.sans, fontSize: 10, padding: '1px 6px', background: 'rgba(180,60,60,0.2)', border: '1px solid rgba(180,60,60,0.4)', color: colors.danger, borderRadius: 2, cursor: 'pointer', flexShrink: 0 }}>
                            Void
                          </button>
                        )}
                        <button onClick={async () => {
                          if (!window.confirm(`DELETE this transaction record entirely?\n\n[${tx.status}] +${tx.player}${tx.droppedPlayer ? ' / -' + tx.droppedPlayer : ''}`)) return;
                          const newTx = transactions.filter((_, i) => i !== tx._i);
                          setTransactions(newTx);
                          await storage.set(STORAGE_KEYS.TRANSACTIONS, newTx);
                          await sfglDataApi.set(STORAGE_KEYS.TRANSACTIONS, newTx);
                          dialog.showToast('Transaction deleted', 'success');
                        }} style={{ fontFamily: fonts.sans, fontSize: 10, padding: '1px 6px', background: 'rgba(100,100,100,0.2)', border: '1px solid rgba(100,100,100,0.4)', color: colors.textMuted, borderRadius: 2, cursor: 'pointer', flexShrink: 0 }}>
                          Delete
                        </button>
                      </div>
                    ))
                  }
                </div>
              </div>
            );
          })()}
        </div>

        {/* Manager Login — expandable */}
        <div style={{ borderTop: `1px solid ${colors.borderSubtle}`, paddingTop: 12 }}>
          <button
            onClick={() => setMgrLoginOpen(v => !v)}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%',
              background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginBottom: mgrLoginOpen ? 12 : 0 }}>
            <span style={{ fontFamily: fonts.sans, fontSize: 12, fontWeight: 600, color: colors.textSecondary, letterSpacing: '0.5px', textTransform: 'uppercase' }}>
              🔑 Manager Login Credentials
            </span>
            <span style={{ fontSize: 11, color: colors.textMuted, transition: 'transform 0.15s', display: 'inline-block', transform: mgrLoginOpen ? 'rotate(180deg)' : 'rotate(0deg)' }}>▼</span>
          </button>
          {mgrLoginOpen && (
            <div>
              <label style={S.lbl}>Team</label>
              <select value={mgCredTeam} onChange={e => { setMgCredTeam(e.target.value); setMgCredName(teams.find(x => x.id === e.target.value)?.owner || ''); }} style={S.select}>
                <option value="">Select team...</option>
                {teams.map(t => <option key={t.id} value={t.id}>{t.name} — {t.owner}</option>)}
              </select>
              <input value={mgCredName} onChange={e => setMgCredName(e.target.value)} placeholder="Login name" style={S.input} />
              <input type="password" value={mgCredPass} onChange={e => setMgCredPass(e.target.value)} placeholder="Password" style={S.input} />
              <button onClick={handleSetLogin} disabled={mgCredSaving || !mgCredTeam || !mgCredName || !mgCredPass}
                style={{ ...S.btn, ...disabledBtn(mgCredSaving || !mgCredTeam || !mgCredName || !mgCredPass) }}>
                {mgCredSaving ? 'Saving...' : 'Set Login'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Draft */}
      <div style={S.section}>
        <div style={S.title}>🎯 Draft</div>
        <button onClick={() => setShowDraftModal(true)} style={S.btn}>Open Draft Room</button>
      </div>

      {/* Danger Zone */}
      <div style={{ ...S.section, borderColor: colors.dangerBorder, background: colors.dangerBg }}>
        <div style={{ ...S.title, color: colors.danger }}>⚠ Danger Zone</div>
        <div style={{ ...theme.smallText, marginBottom: 12 }}>Permanently deletes all results, rosters, transactions, and stats.</div>
        <button onClick={handleReset} style={S.btnDgr}>🔥 Reset Entire Season</button>
      </div>

      {showDraftModal && <DraftModal teams={teams} allPlayers={allPlayers} updateTeams={updateTeams} onClose={() => setShowDraftModal(false)} headshots={headshots} />}
    </div>
  );
};
